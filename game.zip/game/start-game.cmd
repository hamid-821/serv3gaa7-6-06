@echo off
setlocal
cd /d "%~dp0"
set "GAME_NODE=%LOCALAPPDATA%\Programs\GapGPT\resources\bin\node.exe"
if not exist "%GAME_NODE%" set "GAME_NODE=node"
echo Gamify 2 - Open http://localhost:3000 in your browser.
echo Owner key: data\admin-key.txt
"%GAME_NODE%" app.cjs
pause
