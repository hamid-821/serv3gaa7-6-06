import {randomUUID,randomInt} from 'node:crypto';
export class GameError extends Error {constructor(message,status=400){super(message);this.status=status;}}
export const fail=(condition,message,status=400)=>{if(condition)throw new GameError(message,status);};
const parse=JSON.parse;
export class Game {
 constructor(db,notify=()=>{}) {this.db=db;this.notify=notify;this.queue=new Map();}
 get(id){return this.db.prepare('SELECT * FROM matches WHERE id=?').get(id);}
 setting(key){return parse(this.db.prepare('SELECT value FROM settings WHERE key=?').get(key)?.value??'false');}
 active(uid){return this.db.prepare("SELECT id FROM matches WHERE (p1=? OR p2=?) AND state IN ('waiting','playing','reveal') ORDER BY started_at DESC LIMIT 1").get(uid,uid);}
 snapshot(category,reviewUser){
  let rows=reviewUser?this.db.prepare("SELECT q.* FROM questions q JOIN reviews r ON q.id=r.question_id WHERE r.user_id=? AND r.due_at<=? AND q.status='approved' AND COALESCE((SELECT language FROM question_metadata md WHERE md.question_id=q.id),'fa')='fa' ORDER BY r.due_at LIMIT 7").all(reviewUser,Date.now()):this.db.prepare("SELECT * FROM questions WHERE category=? AND status='approved' AND COALESCE((SELECT language FROM question_metadata md WHERE md.question_id=questions.id),'fa')='fa' ORDER BY RANDOM() LIMIT 7").all(category);
  fail(!rows.length,'در این موضوع هنوز سؤال تأییدشده‌ای وجود ندارد.');
  return rows.map(row=>{const opts=parse(row.options).map((text,i)=>({text,correct:i===row.correct})); for(let i=opts.length-1;i>0;i--){const j=randomInt(i+1);[opts[i],opts[j]]=[opts[j],opts[i]];}
   return {...row,options:opts.map(o=>o.text),correct:opts.findIndex(o=>o.correct)};});
 }
 create(uid,category,mode='practice',other=null,tournament=null){
  fail(this.active(uid),'یک مسابقهٔ باز دارید؛ ابتدا آن را ادامه دهید یا پایان دهید.');
  if(other&&mode!=='computer')fail(this.active(other),'حریف در مسابقهٔ دیگری است.');
  const cat=this.db.prepare('SELECT * FROM categories WHERE id=? AND active=1').get(category);fail(!cat,'موضوع پیدا نشد.');
  fail(cat.safety&&!this.setting('safetyReviewed')&&mode!=='practice'&&mode!=='review','سؤالات ایمنی هنوز برای رقابت رسمی به تأیید مسئول ایمنی نرسیده‌اند. تمرین در دسترس است.');
  const eventSnapshot=tournament?this.db.prepare('SELECT questions FROM event_details WHERE event_id=?').get(tournament):null;
  let questions=eventSnapshot?.questions?parse(eventSnapshot.questions):this.snapshot(category,mode==='review'?uid:null);
  fail(!['practice','review'].includes(mode)&&questions.length<7,'برای مسابقهٔ رقابتی، دست‌کم ۷ سؤال تأییدشده لازم است.');
  if(tournament){const league=this.db.prepare('SELECT league_id FROM league_rounds WHERE event_id=?').get(tournament);if(league)fail(this.db.prepare('SELECT status FROM leagues WHERE id=?').get(league.league_id)?.status!=='open'||!this.db.prepare('SELECT 1 FROM league_members WHERE league_id=? AND user_id=?').get(league.league_id,uid),'ابتدا در لیگ ثبت‌نام کن.');const t=this.db.prepare('SELECT * FROM tournaments WHERE id=? AND active=1').get(tournament);fail(!t||t.starts_at>Date.now()||t.ends_at<Date.now()||t.category!==category,'این رویداد در حال برگزاری نیست.');fail(mode!=='tournament','نوع مسابقه برای رویداد معتبر نیست.');fail(this.db.prepare('SELECT 1 FROM matches WHERE tournament=? AND p1=?').get(tournament,uid),'در هر رویداد فقط یک بار می‌توانی شرکت کنی.');let details=this.db.prepare('SELECT questions FROM event_details WHERE event_id=?').get(tournament);if(!details){this.db.prepare("INSERT INTO event_details(event_id,kind,questions) VALUES (?,'event',?)").run(tournament,JSON.stringify(questions));}else questions=parse(details.questions);fail(questions.length!==7,'بانک سؤال رویداد معتبر نیست.');}
  else fail(mode==='tournament','رویداد را انتخاب کنید.');
  if(['online','private','computer'].includes(mode))questions=questions.map(q=>({...q,seconds:10}));
  const id=randomUUID(),now=Date.now(),code=mode==='private'?randomUUID().slice(0,8).toUpperCase():null;
  this.db.prepare('INSERT INTO matches (id,category,mode,state,p1,p2,questions,started_at,round_at,code,tournament) VALUES (?,?,?,?,?,?,?,?,?,?,?)').run(id,category,mode,mode==='private'?'waiting':'playing',uid,other,JSON.stringify(questions),now,now,code,tournament);
  this.db.prepare('INSERT INTO match_details(match_id,intro_until) VALUES (?,?)').run(id,other?now+5000:0);if(other)this.db.prepare('UPDATE matches SET round_at=? WHERE id=?').run(now+5000,id);this.queue.delete(uid);if(other)this.queue.delete(other);return this.view(id,uid);
 }
 join(uid,code){const m=this.db.prepare("SELECT * FROM matches WHERE code=? AND state='waiting'").get(code.toUpperCase());fail(!m,'کد دعوت معتبر نیست یا مسابقه آغاز شده است.');fail(m.p1===uid,'این کد متعلق به خود شماست.');fail(this.active(uid),'ابتدا مسابقهٔ قبلی را تمام کنید.');
  fail(this.blocked(uid,m.p1),'این رقابت در دسترس نیست.',403);
  const cat=this.db.prepare('SELECT safety,active FROM categories WHERE id=?').get(m.category);fail(!cat?.active||(cat.safety&&!this.setting('safetyReviewed')),'این موضوع برای رقابت فعال نیست.');
  this.db.prepare("UPDATE matches SET p2=?,state='playing',round_at=? WHERE id=?").run(uid,Date.now()+5000,m.id);this.db.prepare('INSERT INTO match_details(match_id,intro_until) VALUES (?,?) ON CONFLICT(match_id) DO UPDATE SET intro_until=excluded.intro_until').run(m.id,Date.now()+5000);this.queue.delete(uid);this.notify(m.p1,'match',{id:m.id});return this.view(m.id,uid);
 }
 enqueue(uid,category){
  const existing=this.active(uid);if(existing)return {match:this.view(existing.id,uid)};
  const cat=this.db.prepare('SELECT * FROM categories WHERE id=? AND active=1').get(category);fail(!cat,'موضوع پیدا نشد.');fail(cat.safety&&!this.setting('safetyReviewed'),'موضوع ایمنی فعلاً برای تمرین فعال است.');
  fail(this.db.prepare("SELECT COUNT(*) n FROM questions WHERE category=? AND status='approved'").get(category).n<7,'برای رقابت ۷ سؤال تأییدشده لازم است.');
  this.queue.set(uid,{category,at:Date.now(),joined:this.queue.get(uid)?.joined||Date.now()});
  for(const [other,q] of this.queue){if(other!==uid&&q.category===category&&Date.now()-q.at<45000&&!this.active(other)&&!this.blocked(uid,other)){
    const user=this.db.prepare('SELECT banned FROM users WHERE id=?').get(other);if(user?.banned)continue;
    const match=this.create(uid,category,'online',other);this.notify(other,'match',{id:match.id});return {match};
  }}return {queued:true,category};
 }
 blocked(a,b){return this.db.prepare('SELECT 1 FROM blocks WHERE (user_id=? AND target_id=?) OR (user_id=? AND target_id=?)').get(a,b,b,a);}
 answer(id,uid,round,choice){
  let m=this.get(id);fail(!m||![m.p1,m.p2].includes(uid),'مسابقه پیدا نشد.',404);this.advance(m);m=this.get(id);
  fail(m.state!=='playing'||m.round!==round,'زمان این پرسش تمام شده است.');
  fail(!Number.isInteger(choice)||choice<0||choice>3,'گزینه نامعتبر است.');
  fail(this.db.prepare('SELECT 1 FROM answers WHERE match_id=? AND user_id=? AND round=?').get(id,uid,round),'پاسخ شما قبلاً ثبت شده است.');
  const q=parse(m.questions)[round],elapsed=Date.now()-m.round_at;fail(elapsed<0,'مسابقه پس از معرفی حریف شروع می‌شود.');fail(elapsed>q.seconds*1000,'زمان پاسخ‌گویی پایان یافته است.');
  const double=this.db.prepare("SELECT 1 FROM lifelines WHERE match_id=? AND user_id=? AND round=? AND kind='double'").get(id,uid,round);
  const used=this.db.prepare("SELECT 1 FROM lifelines WHERE match_id=? AND user_id=? AND round=? AND kind='double-used'").get(id,uid,round);
  if(double&&!used&&choice!==q.correct){this.db.prepare('INSERT INTO lifelines VALUES (?,?,?,?)').run(id,uid,round,'double-used');return {retry:true,eliminate:choice};}
  this.record(m,uid,choice,elapsed);this.advance(this.get(id));this.notify(m.p1,'game',{id});if(m.p2)this.notify(m.p2,'game',{id});return this.view(id,uid);
 }
 record(m,uid,choice,elapsed){
  const q=parse(m.questions)[m.round],correct=choice===q.correct;
  let streak=0;for(const a of this.db.prepare('SELECT correct FROM answers WHERE match_id=? AND user_id=? AND round<? ORDER BY round DESC').all(m.id,uid,m.round)){if(!a.correct)break;streak++;}
  const points=correct?100+Math.max(0,Math.min(50,Math.round(50*(1-elapsed/(q.seconds*1000)))))+Math.min(30,streak*10)+(m.round===parse(m.questions).length-1&&streak===m.round?50:0):0;
  const result=this.db.prepare('INSERT OR IGNORE INTO answers VALUES (?,?,?,?,?,?,?,?)').run(m.id,uid,m.round,q.id,choice,Number(correct),points,elapsed);
  if(!result.changes)return;
  if(correct&&elapsed<450&&m.mode!=='computer')this.db.prepare('INSERT INTO security_flags VALUES (?,?,?,?,?,?)').run(randomUUID(),uid,'fast-answer',JSON.stringify({match:m.id,round:m.round,elapsed}),Date.now(),'open');
  const scoreField=uid===m.p1?'score1':'score2';this.db.prepare(`UPDATE matches SET ${scoreField}=${scoreField}+? WHERE id=?`).run(points,m.id);
  if(correct){const rev=this.db.prepare('SELECT interval_days FROM reviews WHERE user_id=? AND question_id=?').get(uid,q.id);if(rev){const interval=Math.min(30,Math.max(1,rev.interval_days*2));this.db.prepare('UPDATE reviews SET due_at=?,interval_days=? WHERE user_id=? AND question_id=?').run(Date.now()+interval*86400000,interval,uid,q.id);}}
  else if(this.db.prepare('SELECT 1 FROM questions WHERE id=?').get(q.id))this.db.prepare('INSERT INTO reviews VALUES (?,?,?,0) ON CONFLICT(user_id,question_id) DO UPDATE SET due_at=excluded.due_at,interval_days=0').run(uid,q.id,Date.now());
 }
 advance(m){
  if(!m)return;
  const now=Date.now(),qs=parse(m.questions);
  if(m.state==='waiting'&&now-m.started_at>600000){this.db.prepare("UPDATE matches SET state='cancelled',finished_at=? WHERE id=?").run(now,m.id);return;}
  if(m.state==='playing'){
   if(now<m.round_at)return;
   if(m.mode==='computer'&&m.p2&&!this.db.prepare('SELECT 1 FROM answers WHERE match_id=? AND user_id=? AND round=?').get(m.id,m.p2,m.round)){
    const bot=this.db.prepare('SELECT * FROM bot_profiles WHERE user_id=?').get(m.p2),q=qs[m.round];let planned=this.db.prepare('SELECT * FROM bot_answers WHERE match_id=? AND round=? AND user_id=?').get(m.id,m.round,m.p2);
    if(!planned){const delay=randomInt(2000,Math.max(2001,Math.min(9000,q.seconds*1000-500))),choice=randomInt(1000)<(bot?.accuracy||.65)*1000?q.correct:[0,1,2,3].filter(i=>i!==q.correct)[randomInt(3)];this.db.prepare('INSERT INTO bot_answers VALUES (?,?,?,?,?)').run(m.id,m.round,m.p2,m.round_at+delay,choice);planned={at:m.round_at+delay,choice};}
    if(now>=planned.at)this.record(m,m.p2,planned.choice,planned.at-m.round_at);
   }
   const q=qs[m.round],players=[m.p1,m.p2].filter(Boolean);
   if(now-m.round_at>=q.seconds*1000)for(const p of players)this.record(m,p,-1,q.seconds*1000);
   const count=this.db.prepare('SELECT COUNT(*) n FROM answers WHERE match_id=? AND round=?').get(m.id,m.round).n;
   if(count===players.length)this.db.prepare("UPDATE matches SET state='reveal',round_at=? WHERE id=?").run(now,m.id);
  }else if(m.state==='reveal'&&now-m.round_at>4500){
   if(m.round+1===qs.length)this.finish(m);
   else this.db.prepare("UPDATE matches SET state='playing',round=round+1,round_at=? WHERE id=?").run(now,m.id);
  }
 }
 finish(m){
  if(m.rewarded)return;
  const now=Date.now(),day=new Date(now).toISOString().slice(0,10),yesterday=new Date(now-86400000).toISOString().slice(0,10);
  this.db.exec('BEGIN IMMEDIATE');try{
   if(!this.db.prepare("UPDATE matches SET state='finished',finished_at=?,rewarded=1 WHERE id=? AND rewarded=0").run(now,m.id).changes){this.db.exec('COMMIT');return;}
   for(const [i,uid] of [m.p1,m.p2].entries())if(uid){
    const correct=this.db.prepare('SELECT COUNT(*) n FROM answers WHERE match_id=? AND user_id=? AND correct=1').get(m.id,uid).n;
    const win=m.p2&&(i===0?m.score1>m.score2:m.score2>m.score1)?1:0,points=correct*10+win*30;
    const user=this.db.prepare('SELECT * FROM users WHERE id=?').get(uid);if(user.role==='bot')continue;const daily=user.last_daily!==day;
    if(win&&!this.db.prepare("SELECT 1 FROM matches WHERE id<>? AND state='finished' AND ((p1=? AND score1>score2) OR (p2=? AND score2>score1)) AND p2 IS NOT NULL").get(m.id,uid,uid))this.db.prepare('UPDATE match_details SET first_win=? WHERE match_id=?').run(uid,m.id);
    this.db.prepare('UPDATE users SET xp=xp+?,coins=coins+?,cups=cups+?,streak=?,last_daily=? WHERE id=?').run(points,correct*2+win*20+(daily?25:0),win,daily?(user.last_daily===yesterday?user.streak+1:1):user.streak,day,uid);
    this.db.prepare('INSERT INTO category_stats VALUES (?,?,?,?,1) ON CONFLICT(user_id,category) DO UPDATE SET xp=xp+excluded.xp,wins=wins+excluded.wins,played=played+1').run(uid,m.category,points,win);
   }
   if(m.p2&&m.mode!=='computer'){
    for(const p of [m.p1,m.p2])this.db.prepare('INSERT OR IGNORE INTO player_details(user_id) VALUES (?)').run(p);
    const r1=this.db.prepare('SELECT rating FROM player_details WHERE user_id=?').get(m.p1).rating,r2=this.db.prepare('SELECT rating FROM player_details WHERE user_id=?').get(m.p2).rating;
    const actual=m.score1===m.score2?.5:m.score1>m.score2?1:0,delta=Math.round(24*(actual-1/(1+10**((r2-r1)/400))));
    this.db.prepare('UPDATE player_details SET rating=rating+? WHERE user_id=?').run(delta,m.p1);this.db.prepare('UPDATE player_details SET rating=rating-? WHERE user_id=?').run(delta,m.p2);this.db.prepare('UPDATE match_details SET rating1=?,rating2=? WHERE match_id=?').run(delta,-delta,m.id);
   }
   this.db.exec('COMMIT');
  }catch(e){this.db.exec('ROLLBACK');throw e;}
 }
 cancel(id,uid){const m=this.get(id);fail(!m||![m.p1,m.p2].includes(uid),'مسابقه پیدا نشد.',404);fail(['finished','cancelled'].includes(m.state),'مسابقه پایان یافته است.');
  if(m.p2){this.db.prepare('UPDATE match_details SET forfeit=? WHERE match_id=?').run(uid,id);const winner=uid===m.p1?'score2':'score1';this.db.prepare(`UPDATE matches SET ${winner}=MAX(score1,score2)+1 WHERE id=?`).run(id);this.finish(this.get(id));}
  else this.db.prepare("UPDATE matches SET state='cancelled',finished_at=? WHERE id=?").run(Date.now(),id);
  this.notify(m.p1,'game',{id});if(m.p2)this.notify(m.p2,'game',{id});
 }
 lifeline(id,uid,kind){
  const m=this.get(id);fail(!m||![m.p1,m.p2].includes(uid),'مسابقه پیدا نشد.',404);const q=parse(m.questions)[m.round];
  fail(!['practice','review'].includes(m.mode),'کمک آموزشی در تمرین فعال است؛ رقابت برای همه شرایط یکسان دارد.');
  fail(m.state!=='playing'||Date.now()-m.round_at>=q.seconds*1000,'زمان کمک به پایان رسیده است.');
  fail(!['fifty','hint','double'].includes(kind),'کمک نامعتبر است.');
  fail(this.db.prepare('SELECT 1 FROM answers WHERE match_id=? AND user_id=? AND round=?').get(id,uid,m.round),'پاسخ قبلاً ثبت شده است.');
  fail(this.db.prepare('SELECT 1 FROM lifelines WHERE match_id=? AND user_id=? AND kind=?').get(id,uid,kind),'این کمک در این مسابقه استفاده شده است.');
  const price={fifty:20,hint:0,double:15}[kind];fail(this.db.prepare('SELECT coins FROM users WHERE id=?').get(uid).coins<price,'سکهٔ کافی ندارید.');
  this.db.prepare('UPDATE users SET coins=coins-? WHERE id=?').run(price,uid);this.db.prepare('INSERT INTO lifelines VALUES (?,?,?,?)').run(id,uid,m.round,kind);
  return {kind,eliminate:kind==='fifty'?[0,1,2,3].filter(i=>i!==q.correct).slice(0,2):[],hint:kind==='hint'?q.explanation:null};
 }
 view(id,uid){
  let m=this.get(id);fail(!m||![m.p1,m.p2].includes(uid),'مسابقه پیدا نشد.',404);this.advance(m);m=this.get(id);
  const qs=parse(m.questions),q=qs[m.round],players=[m.p1,m.p2].filter(Boolean).map((id,i)=>({...this.db.prepare('SELECT u.id,u.name,u.avatar,u.role,d.country,d.city,d.occupation,d.specialty,d.rating FROM users u LEFT JOIN player_details d ON d.user_id=u.id WHERE u.id=?').get(id),score:i===0?m.score1:m.score2,answered:!!this.db.prepare('SELECT 1 FROM answers WHERE match_id=? AND user_id=? AND round=?').get(m.id,id,m.round)}));
  const revealed=['reveal','finished'].includes(m.state);
  const mine=this.db.prepare('SELECT choice,points,correct FROM answers WHERE match_id=? AND user_id=? AND round=?').get(id,uid,m.round);
  const details=this.db.prepare('SELECT * FROM match_details WHERE match_id=?').get(m.id)||{},intro=m.state==='playing'&&Date.now()<m.round_at;
  const question=m.state==='waiting'||intro?null:{id:q.id,title:q.title,options:q.options,seconds:q.seconds,kind:q.kind,media:q.media,audio:q.audio,...(revealed?{correct:q.correct,explanation:q.explanation,source:q.source}:{})};
  return {id:m.id,category:m.category,mode:m.mode,state:intro?'intro':m.state,introUntil:intro?m.round_at:null,result:m.state==='finished'?(m.p2?(m.score1===m.score2?'draw':((uid===m.p1?m.score1:m.score2)>(uid===m.p1?m.score2:m.score1)?'win':'loss')):'practice'):null,firstWin:details.first_win===uid,ratingChange:uid===m.p1?details.rating1:details.rating2,forfeit:details.forfeit,totalWins:this.db.prepare("SELECT COUNT(*) n FROM matches WHERE state='finished' AND p2 IS NOT NULL AND ((p1=? AND score1>score2) OR (p2=? AND score2>score1))").get(uid,uid).n,round:m.round,total:qs.length,question,players,code:m.code,deadline:m.state==='playing'?m.round_at+q.seconds*1000:null,serverTime:Date.now(),myChoice:mine?.choice??null,...(revealed?{myAnswer:mine}:{}),history:m.state==='finished'?this.db.prepare('SELECT question_id,choice,correct,points,round FROM answers WHERE match_id=? AND user_id=? ORDER BY round').all(id,uid).map(a=>({...a,question:qs[a.round].title,explanation:qs[a.round].explanation,answer:qs[a.round].options[qs[a.round].correct]})):[]};
 }
 tick(){for(const m of this.db.prepare("SELECT * FROM matches WHERE state IN ('playing','reveal','waiting')").all())this.advance(m);for(const [id,q] of this.queue)if(Date.now()-q.at>45000)this.queue.delete(id);}
}
