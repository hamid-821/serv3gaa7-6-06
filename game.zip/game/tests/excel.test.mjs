import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {createRequire} from 'node:module';
import {createApp} from '../server/index.mjs';
import {HEADERS,mapRows,parseWorkbook} from '../server/excel.mjs';
const require=createRequire(import.meta.url),ExcelJS=require('../server/vendor/exceljs.cjs');
test('Persian Excel template: correct answer, row numbers, real XLSX parsing',async()=>{
 const rows=await parseWorkbook(readFileSync(new URL('../public/templates/gamify-2-questions.xlsx',import.meta.url)));
 const mapped=mapRows(rows,[{id:'electric',name:'دنیای برق'},{id:'work',name:'تجربه‌های کاری'}]);
 assert.equal(mapped.length,3);assert.equal(mapped[0].row,2);assert.equal(mapped[0].question.correct,2);assert.equal(mapped[0].question.options[2],'اهم');
});
test('Localized digits, category names, invalid answers and duplicate headers',()=>{
 const values=['دنیای برق','سؤال آزمون','الف','ب','ج','د','۴','توضیح پاسخ','۳۰','متنی','','',''];
 let rows=mapRows([{row:1,values:HEADERS},{row:5,values}],[{id:'electric',name:'دنیای برق'}]);assert.equal(rows[0].question.correct,3);assert.equal(rows[0].question.seconds,30);
 values[6]=0;rows=mapRows([{row:1,values:HEADERS},{row:5,values}],[{id:'electric',name:'دنیای برق'}]);assert.equal(rows[0].row,5);assert.match(rows[0].error,/گزینه صحیح/);
 assert.throws(()=>mapRows([{row:1,values:[...HEADERS,HEADERS[0]]}],[{id:'electric',name:'دنیای برق'}]),/تکراری/);
});
test('Reject formulas and invalid XLSX input',async()=>{
 await assert.rejects(parseWorkbook(Buffer.from('not a spreadsheet')),/XLSX/);
 const w=new ExcelJS.Workbook(),s=w.addWorksheet('سؤالات');s.addRow(HEADERS);s.addRow(['electric',{formula:'1+1',result:2},'a','b','c','d',1,'explanation']);
 await assert.rejects(parseWorkbook(Buffer.from(await w.xlsx.writeBuffer())),/فرمول/);
});
test('HTTP import permission, preview, atomic commit, duplicate protection and manual editing',async()=>{
 mkdirSync('audit/test-runs',{recursive:true});const dir=mkdtempSync(resolve('audit/test-runs/excel-'));
 const app=createApp({dataDir:dir,baseUrl:'http://localhost:3000',adminKey:'test-admin-key-01234567890123456789',testing:true});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;
 let cookie='',csrf='';
 const call=async(path,method='GET',body)=>{const res=await fetch(base+'/api'+path,{method,headers:{'Content-Type':'application/json',Origin:'http://localhost:3000',Cookie:cookie,'X-CSRF-Token':csrf},...(body?{body:JSON.stringify(body)}:{})});if(res.headers.get('set-cookie'))cookie=res.headers.get('set-cookie').split(';')[0];return {status:res.status,data:await res.json()};};
 try{
  assert.equal((await call('/admin/excel/preview','POST',{data:''})).status,401);
  let result=await call('/auth/guest','POST',{name:'مدیر آزمایشی',avatar:1,interests:['electric']});assert.equal(result.status,201);csrf=result.data.csrf;
  assert.equal((await call('/admin/excel/preview','POST',{data:''})).status,403);
  assert.equal((await call('/admin/unlock','POST',{key:'test-admin-key-01234567890123456789'})).status,200);
  const data=readFileSync(new URL('../public/templates/gamify-2-questions.xlsx',import.meta.url)).toString('base64');
  const before=app.db.prepare('SELECT COUNT(*) n FROM questions').get().n;
  result=await call('/admin/excel/preview','POST',{data});assert.equal(result.status,200,JSON.stringify(result.data));assert.equal(result.data.errors,0,JSON.stringify(result.data));
  const token=result.data.token;assert.equal(app.db.prepare('SELECT COUNT(*) n FROM questions').get().n,before);
  result=await call('/admin/excel/commit','POST',{token,status:'approved'});assert.equal(result.status,200,JSON.stringify(result.data));assert.equal(result.data.count,3);assert.equal(app.db.prepare('SELECT COUNT(*) n FROM questions').get().n,before+3);
  assert.equal((await call('/admin/excel/commit','POST',{token,status:'approved'})).status,400);
  result=await call('/admin/excel/preview','POST',{data});assert.equal(result.data.errors,3);assert.equal((await call('/admin/excel/commit','POST',{token:result.data.token,status:'approved'})).status,400);
  const q=app.db.prepare("SELECT * FROM questions WHERE title='واحد اندازه‌گیری مقاومت الکتریکی کدام است؟'").get();assert.equal(q.correct,2);
  result=await call('/admin/questions','POST',{...q,options:JSON.parse(q.options),title:q.title+' (ویرایش)'});assert.equal(result.status,200,JSON.stringify(result.data));
  assert.equal((await call('/admin/questions/'+q.id,'DELETE')).status,200);
  result=await call('/feed','POST',{category:'work',body:'تجربهٔ آزمایشی برای بررسی ذخیره‌سازی',media:'',audio:''});assert.equal(result.status,201,JSON.stringify(result.data));
  const file=await fetch(base+'/templates/gamify-2-questions.xlsx');assert.equal(file.status,200);assert.equal((await file.arrayBuffer()).byteLength,Buffer.from(data,'base64').length);
  const wb=new ExcelJS.Workbook(),ws=wb.addWorksheet('سؤالات');ws.addRow(HEADERS);
  ws.addRow(['electric','یک سؤال تازه برای آزمایش ورود ناقص','الف','ب','ج','د',1,'توضیح کافی برای آزمون',25,'متنی']);
  ws.addRow(['electric','یک سؤال با پاسخ نامعتبر برای آزمون','الف','ب','ج','د',9,'توضیح کافی برای آزمون',25,'متنی']);
  const mixed=Buffer.from(await wb.xlsx.writeBuffer()).toString('base64');result=await call('/admin/excel/preview','POST',{data:mixed});assert.equal(result.data.valid,1);assert.equal(result.data.errors,1);
  assert.equal((await call('/admin/excel/commit','POST',{token:result.data.token,status:'approved'})).status,400);assert.equal(app.db.prepare("SELECT COUNT(*) n FROM questions WHERE title='یک سؤال تازه برای آزمایش ورود ناقص'").get().n,0);
  assert.equal(app.db.prepare('SELECT COUNT(*) n FROM categories').get().n,20);
  assert.equal((await call('/admin/demo-users')).data.length,50);const realUserCount=app.db.prepare('SELECT COUNT(*) n FROM users WHERE is_demo=0').get().n;
  assert.equal((await call('/admin/demo-users','DELETE',{})).data.count,50);assert.equal(app.db.prepare('SELECT COUNT(*) n FROM users WHERE is_demo=0').get().n,realUserCount);
  assert.equal(app.db.prepare("SELECT COUNT(*) n FROM posts WHERE id LIKE 'demo-post-%'").get().n,0);
 }finally{await app.close();}
});
