export async function socialRoute(ctx){
 const {path,method,url,b,u,db,game,json,res,fail,text,media,postAccess,setting,audit,transaction}=ctx;
 if(!path.startsWith('/api/social/'))return false;
 const done=value=>{json(res,value);return true;};
 if(path==='/api/social/feed'&&method==='GET'){
  fail(!setting('feedEnabled'),'فید با تنظیم مدیر موقتاً غیرفعال است.',403);
  const viewer=u?.id||'',params=url.searchParams,scope=params.get('scope')||'all',category=params.get('category')||'',author=params.get('author')||'',q=(params.get('q')||'').trim().slice(0,100);
  fail(!['all','mine','following','saved'].includes(scope),'فیلتر فید معتبر نیست.');fail(scope!=='all'&&!u,'برای این بخش وارد حساب شوید.',401);
  const asOf=Math.min(Date.now(),Math.max(0,Number(params.get('asOf'))||Date.now()));
  const offset=Math.max(0,Math.min(10000,Number(params.get('offset'))||0));
  const rows=db.prepare(`SELECT p.*,a.name,a.avatar,a.is_demo FROM posts p JOIN users a ON a.id=p.user_id
   WHERE a.banned=0 AND (p.status='approved' OR p.user_id=?) AND (?='' OR p.category=?) AND (?='' OR p.user_id=?) AND p.body LIKE ?
   AND (a.private=0 OR a.id=? OR EXISTS(SELECT 1 FROM follows f WHERE f.user_id=? AND f.target_id=a.id AND f.status='approved'))
   AND NOT EXISTS(SELECT 1 FROM blocks k WHERE (k.user_id=? AND k.target_id=a.id) OR (k.user_id=a.id AND k.target_id=?))
   ${scope==='mine'?'AND p.user_id=?':''}
   ${scope==='following'?"AND EXISTS(SELECT 1 FROM follows f WHERE f.user_id=? AND f.target_id=a.id AND f.status='approved')":''}
   ${scope==='saved'?'AND EXISTS(SELECT 1 FROM bookmarks bm WHERE bm.user_id=? AND bm.post_id=p.id)':''}
   ORDER BY ${scope==='all'?'CASE WHEN EXISTS(SELECT 1 FROM feed_seen fs WHERE fs.user_id=? AND fs.post_id=p.id AND fs.seen_at<?) THEN 1 ELSE 0 END,':''} p.created_at DESC,p.id LIMIT 21 OFFSET ?`).all(viewer,category,category,author,author,'%'+q+'%',viewer,viewer,viewer,viewer,...(scope==='all'?[]:[viewer]),...(scope==='all'?[viewer,asOf]:[]),offset);
  return done({asOf,hasMore:rows.length>20,posts:rows.slice(0,20).map(p=>({...p,isDemo:!!p.is_demo,canEdit:p.user_id===viewer||u?.role==='admin',likes:db.prepare('SELECT COUNT(*) n FROM likes WHERE post_id=?').get(p.id).n,liked:!!db.prepare('SELECT 1 FROM likes WHERE post_id=? AND user_id=?').get(p.id,viewer),saved:!!db.prepare('SELECT 1 FROM bookmarks WHERE post_id=? AND user_id=?').get(p.id,viewer),comments:db.prepare("SELECT COUNT(*) n FROM comments WHERE post_id=? AND (status='approved' OR user_id=?)").get(p.id,viewer).n}))});
 }
 fail(!u,'ابتدا وارد حساب شوید.',401);
 if(path==='/api/social/seen'&&method==='POST'){fail(!Array.isArray(b.ids)||b.ids.length>20,'فهرست معتبر نیست.');transaction(()=>{for(const id of b.ids){postAccess(id,u);db.prepare('INSERT OR IGNORE INTO feed_seen VALUES (?,?,?)').run(u.id,id,Date.now());}});return done({ok:true});}
 const likes=path.match(/^\/api\/social\/posts\/([^/]+)\/likes$/);
 if(likes&&method==='GET'){postAccess(likes[1],u);return done(db.prepare('SELECT a.id,a.name,a.avatar,a.is_demo FROM likes l JOIN users a ON l.user_id=a.id WHERE l.post_id=? AND a.banned=0 LIMIT 100').all(likes[1]).filter(x=>!game.blocked(u.id,x.id)));}
 const post=path.match(/^\/api\/social\/posts\/([^/]+)$/);
 if(post&&['PATCH','DELETE'].includes(method)){
  const p=postAccess(post[1],u);fail(p.user_id!==u.id&&u.role!=='admin','فقط نویسنده یا مدیر می‌تواند این پست را تغییر دهد.',403);
  if(method==='DELETE'){db.prepare('DELETE FROM posts WHERE id=?').run(p.id);audit(u.id,'delete-post',p.id);return done({ok:true});}
  const body=text(b.body,3,4000),file=b.media===p.media?p.media:media(b.media,u.id),audio=b.audio===p.audio?p.audio:media(b.audio,u.id,['audio/']);
  fail(!db.prepare('SELECT 1 FROM categories WHERE id=? AND active=1').get(b.category),'دسته‌بندی معتبر نیست.');
  const status=u.role==='admin'?(b.status||p.status):setting('moderatePosts')?'pending':'approved';fail(!['pending','approved','rejected'].includes(status),'وضعیت معتبر نیست.');
  db.prepare('UPDATE posts SET body=?,category=?,media=?,audio=?,status=? WHERE id=?').run(body,b.category,file,audio,status,p.id);audit(u.id,'edit-post',p.id);return done({id:p.id,status});
 }
 const comment=path.match(/^\/api\/social\/comments\/([^/]+)$/);
 if(comment&&method==='DELETE'){
  const c=db.prepare('SELECT * FROM comments WHERE id=?').get(comment[1]);fail(!c,'نظر پیدا نشد.',404);postAccess(c.post_id,u);fail(c.user_id!==u.id&&u.role!=='admin','حذف این نظر مجاز نیست.',403);db.prepare('DELETE FROM comments WHERE id=?').run(c.id);return done({ok:true});
 }
 if(path==='/api/social/requests'&&method==='GET')return done(db.prepare("SELECT u.id,u.name,u.avatar FROM follows f JOIN users u ON f.user_id=u.id WHERE f.target_id=? AND f.status='pending' AND u.banned=0").all(u.id).filter(x=>!game.blocked(u.id,x.id)));
 return false;
}
