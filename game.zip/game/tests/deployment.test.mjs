import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdirSync,mkdtempSync,existsSync,readFileSync,readdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {buildVercel} from '../scripts/build-vercel.mjs';
test('Vercel build requires persistent HTTPS backend and excludes server/private files',()=>{
 assert.throws(()=>buildVercel({backend:''}),/BACKEND_ORIGIN/);
 for(const backend of ['http://example.com','https://name:password@example.com','https://example.com/api','https://example.com/?secret=x'])assert.throws(()=>buildVercel({backend}),/origin/);
 mkdirSync('audit/test-runs',{recursive:true});const output=join(mkdtempSync(resolve('audit/test-runs/deploy-')),'output');const config=buildVercel({backend:'https://backend.example.com',output});assert.equal(config.version,3);assert.ok(existsSync(join(output,'static','app.js')));assert.ok(!existsSync(join(output,'static','server')));assert.ok(!existsSync(join(output,'static','data')));
 const proxy=config.routes[0];for(const path of ['/api/auth/guest','/auth/google/callback','/uploads/photo.png'])assert.equal(path.replace(new RegExp('^'+proxy.src+'$'),proxy.dest),'https://backend.example.com'+path);assert.equal(proxy.headers['Cache-Control'],'no-store');assert.equal(JSON.parse(readFileSync(join(output,'static','manifest.webmanifest'),'utf8')).icons.length,2);
 const walk=dir=>readdirSync(dir,{withFileTypes:true}).flatMap(d=>d.isDirectory()?walk(join(dir,d.name)):[join(dir,d.name)]);assert.ok(!walk(output).some(p=>/admin-key|\.sqlite|\.env$/.test(p)));
});
