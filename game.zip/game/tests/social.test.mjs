import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {createApp} from '../server/index.mjs';
const png='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jG7cAAAAASUVORK5CYII=';
test('Social flow: real and demo chat, private images, inbox, moderated feed, likes, comments and editing',async()=>{
 mkdirSync('audit/test-runs',{recursive:true});const app=createApp({dataDir:mkdtempSync(resolve('audit/test-runs/social-')),baseUrl:'http://localhost:3000',adminKey:'social-test-key-0123456789012345',testing:true});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;
 function client(){let cookie='',csrf='';return {id:'',async call(path,method='GET',body){const res=await fetch(base+(path.startsWith('/uploads/')?path:'/api'+path),{method,headers:{Origin:'http://localhost:3000','Content-Type':'application/json',Cookie:cookie,'X-CSRF-Token':csrf},...(body?{body:JSON.stringify(body)}:{})});if(res.headers.get('set-cookie'))cookie=res.headers.get('set-cookie').split(';')[0];const data=res.headers.get('content-type')?.includes('application/json')?await res.json():Buffer.from(await res.arrayBuffer());if(data.csrf){csrf=data.csrf;this.id=data.user.id;}return {status:res.status,data};}};}
 const a=client(),b=client(),outsider=client(),admin=client();
 try{
  for(const [i,c]of [a,b,outsider,admin].entries())assert.equal((await c.call('/auth/guest','POST',{name:'کاربر آزمون '+i,avatar:i+1,interests:['work']})).status,201);
  await admin.call('/admin/unlock','POST',{key:'social-test-key-0123456789012345'});
  const image=await a.call('/upload','POST',{mime:'image/png',data:png});assert.equal(image.status,201,JSON.stringify(image.data));const path=image.data.path;
  assert.equal((await a.call('/messages/'+b.id,'POST',{body:'سلام، این تصویر آزمایشی است.',media:path})).status,201);
  let messages=await b.call('/messages/'+a.id);assert.equal(messages.data.length,1);assert.equal(messages.data[0].media,path);
  assert.equal((await b.call(path)).status,200);assert.equal((await outsider.call(path)).status,403);
  assert.equal((await b.call('/messages/read','PATCH',{id:a.id})).status,200);assert.equal((await a.call('/messages/'+b.id)).data[0].seen,1);
  let inbox=await b.call('/conversations');assert.equal(inbox.data[0].id,a.id);assert.equal(inbox.data[0].unread,0);
  assert.equal((await a.call('/messages/demo-v2-1','POST',{body:'پیام آزمایشی به حساب نمونه',media:path})).status,201);inbox=await a.call('/conversations');assert.ok(inbox.data.some(p=>p.is_demo===1));
  assert.equal((await b.call('/messages/demo-v2-1')).data.length,0,'Demo chat must not leak another player conversation');
  const post=await a.call('/feed','POST',{body:'تجربهٔ منتشرشونده با عکس برای آزمون',category:'work',media:path,audio:''});assert.equal(post.status,201);assert.equal(post.data.status,'pending');const postId=post.data.id;
  assert.ok((await a.call('/social/feed?scope=mine')).data.posts.some(p=>p.id===postId));assert.equal((await b.call('/social/feed?author='+a.id)).data.posts.length,0);
  await admin.call('/admin/moderation','PATCH',{kind:'post',id:postId,status:'approved'});assert.ok((await b.call('/social/feed?author='+a.id)).data.posts.some(p=>p.id===postId));
  assert.equal((await b.call('/posts/'+postId+'/like','POST',{})).data.active,true);assert.equal((await a.call('/social/posts/'+postId+'/likes')).data[0].id,b.id);
  await b.call('/posts/'+postId+'/save','POST',{});assert.equal((await b.call('/social/feed?scope=saved')).data.posts[0].id,postId);
  assert.equal((await b.call('/posts/'+postId+'/comments','POST',{body:'نظر آزمایشی'})).data.status,'pending');assert.equal((await a.call('/posts/'+postId+'/comments')).data.length,0);
  const comment=(await b.call('/posts/'+postId+'/comments')).data[0];await admin.call('/admin/moderation','PATCH',{kind:'comment',id:comment.id,status:'approved'});assert.equal((await a.call('/posts/'+postId+'/comments')).data.length,1);
  assert.equal((await outsider.call('/social/comments/'+comment.id,'DELETE',{})).status,403);assert.equal((await b.call('/social/comments/'+comment.id,'DELETE',{})).status,200);
  assert.equal((await outsider.call('/social/posts/'+postId,'PATCH',{body:'تغییر غیرمجاز',category:'work',media:'',audio:''})).status,403);
  const edit=await a.call('/social/posts/'+postId,'PATCH',{body:'تجربهٔ اصلاح‌شده با همان تصویر',category:'work',media:path,audio:''});assert.equal(edit.status,200);assert.equal(edit.data.status,'pending');
  assert.equal((await a.call('/social/posts/'+postId,'DELETE',{})).status,200);assert.equal((await b.call('/social/feed?scope=saved')).data.posts.length,0);
  await b.call('/block','POST',{id:a.id});assert.equal((await a.call('/messages/'+b.id,'POST',{body:'پس از مسدودی',media:''})).status,403);
 }finally{await app.close();}
});
