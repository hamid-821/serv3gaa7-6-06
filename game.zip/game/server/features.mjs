import {randomInt,randomUUID} from 'node:crypto';
const ITEMS=[{id:'frame-gold',name:'قاب طلایی قهرمان',price:120,icon:'crown',kind:'frame',description:'یک قاب طلایی برای آواتار پروفایلت.'},{id:'frame-violet',name:'قاب بنفش کهکشانی',price:80,icon:'spark',kind:'frame',description:'درخشش بنفش دور آواتار تو.'},{id:'title-mentor',name:'نشان استاد تجربه',price:200,icon:'medal',kind:'title',description:'یک عنوان تزئینی زیر نامت؛ نشان صلاحیت حرفه‌ای نیست.'},{id:'emoji-stars',name:'بستهٔ ایموجی قهرمان',price:60,icon:'spark',kind:'emoji',description:'شش واکنش برای گفت‌وگو: 🌟 🏆 🎯 🎉 💡 🚀'}];
export function rankedPlayers(db,{category='',period='all',metric='xp',userId=null,country='',city=''}){
 const value=metric==='cups'?'cups':'xp';let sql,params=[];
 if(period==='all'){
  sql=category?`SELECT u.*,s.${value==='cups'?'wins':'xp'} rankPoints FROM users u JOIN category_stats s ON s.user_id=u.id WHERE s.category=? AND s.${value==='cups'?'wins':'xp'}>0`:`SELECT u.*,u.${value} rankPoints FROM users u WHERE u.${value}>0`;
  if(category)params.push(category);
 }else{
  const since=Date.now()-(period==='month'?30:7)*86400000;
  sql=`WITH entries AS (
   SELECT m.p1 user_id,m.category,m.finished_at,10*(SELECT COUNT(*) FROM answers a WHERE a.match_id=m.id AND a.user_id=m.p1 AND a.correct=1)+CASE WHEN m.p2 IS NOT NULL AND m.score1>m.score2 THEN 30 ELSE 0 END xp,CASE WHEN m.p2 IS NOT NULL AND m.score1>m.score2 THEN 1 ELSE 0 END cups FROM matches m WHERE m.state='finished'
   UNION ALL SELECT m.p2,m.category,m.finished_at,10*(SELECT COUNT(*) FROM answers a WHERE a.match_id=m.id AND a.user_id=m.p2 AND a.correct=1)+CASE WHEN m.score2>m.score1 THEN 30 ELSE 0 END,CASE WHEN m.score2>m.score1 THEN 1 ELSE 0 END FROM matches m WHERE m.state='finished' AND m.p2 IS NOT NULL
   UNION ALL SELECT a.user_id,t.category,s.settled_at,0,1 FROM event_awards a JOIN tournaments t ON t.id=a.event_id JOIN event_settled s ON s.event_id=t.id WHERE a.rank=1)
   SELECT u.*,SUM(e.${value}) rankPoints FROM users u JOIN entries e ON e.user_id=u.id WHERE e.finished_at>? AND (?='' OR e.category=?) GROUP BY u.id HAVING SUM(e.${value})>0`;
  params.push(since,category,category);
 }
 if(metric==='rating'){sql="SELECT u.*,COALESCE(d.rating,1200) rankPoints FROM users u LEFT JOIN player_details d ON d.user_id=u.id WHERE EXISTS(SELECT 1 FROM matches m WHERE m.state='finished' AND m.mode IN ('online','private') AND (m.p1=u.id OR m.p2=u.id))";params=[];}
 const ranked=`WITH scores AS (${sql}), ranked AS (SELECT id,name,avatar,cups,private,rankPoints,ROW_NUMBER() OVER(ORDER BY rankPoints DESC,created_at ASC,id ASC) rank FROM scores WHERE banned=0 AND is_demo=0 AND (?='' OR (private=0 AND EXISTS(SELECT 1 FROM player_details d WHERE d.user_id=scores.id AND d.country=?))) AND (?='' OR (private=0 AND EXISTS(SELECT 1 FROM player_details d WHERE d.user_id=scores.id AND d.city=?)))) SELECT * FROM ranked ${userId?'WHERE id=?':'ORDER BY rank LIMIT 100'}`;
 return db.prepare(ranked).all(...params,country.slice(0,70),country.slice(0,70),city.slice(0,70),city.slice(0,70),...(userId?[userId]:[])).map(x=>({...x,points:x.rankPoints}));
}
export function competitionRanks(db,id){return db.prepare("SELECT u.id,u.name,u.avatar,m.score1 points,m.finished_at,(SELECT COUNT(*) FROM answers a WHERE a.match_id=m.id AND a.user_id=u.id AND a.correct=1) correct FROM matches m JOIN users u ON u.id=m.p1 WHERE m.tournament=? AND m.state='finished' AND u.banned=0 AND u.is_demo=0 ORDER BY m.score1 DESC,m.finished_at ASC,m.id ASC").all(id).map((x,i)=>({...x,rank:i+1}));}
export function settleCompetitions(db){
 const now=Date.now(),events=db.prepare("SELECT t.id FROM tournaments t WHERE t.ends_at<=? AND NOT EXISTS(SELECT 1 FROM event_settled s WHERE s.event_id=t.id) AND NOT EXISTS(SELECT 1 FROM matches m WHERE m.tournament=t.id AND m.state IN ('playing','reveal','waiting'))").all(now);
 for(const t of events){const winners=competitionRanks(db,t.id).filter(x=>x.points>0).slice(0,3);db.exec('BEGIN IMMEDIATE');try{if(!db.prepare('INSERT OR IGNORE INTO event_settled VALUES (?,?)').run(t.id,now).changes){db.exec('COMMIT');continue;}for(const [i,w]of winners.entries()){const coins=[100,60,30][i];db.prepare('INSERT INTO event_awards VALUES (?,?,?,?)').run(t.id,w.id,i+1,coins);db.prepare('UPDATE users SET coins=coins+?,cups=cups+? WHERE id=?').run(coins,i===0?1:0,w.id);db.prepare('INSERT INTO notifications VALUES (?,?,?,?,?,0)').run(randomUUID(),w.id,'افتخار تازه در مسابقه',`رتبهٔ ${i+1} و ${coins} سکه دریافت کردی.`,now);}db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}}
}
function rewardState(db,id){const last=db.prepare("SELECT MAX(created_at) at FROM reward_claims WHERE user_id=? AND kind='daily'").get(id)?.at||0;const qualifying=db.prepare("SELECT COUNT(*) n FROM matches m WHERE (m.p1=? OR m.p2=?) AND state='finished' AND (SELECT COUNT(*) FROM answers a WHERE a.match_id=m.id AND a.user_id=? AND a.correct=1)>=3").get(id,id,id).n;const claimed=db.prepare("SELECT COUNT(*) n FROM reward_claims WHERE user_id=? AND kind='chest'").get(id).n;return {nextDailyAt:last?last+86400000:0,qualifying,chestsClaimed:claimed,chestsAvailable:Math.max(0,Math.floor(qualifying/5)-claimed),nextChestProgress:qualifying%5};}
export async function featuresRoute(ctx){
 const {path,method,url,b,u,db,game,json,res,fail,text,transaction,setting,audit,notice}=ctx;if(!path.startsWith('/api/features/'))return false;
 const done=value=>{json(res,value);return true;};
 if(path==='/api/features/competitions'&&method==='GET'){
  settleCompetitions(db);return done(db.prepare('SELECT t.*,d.kind,d.creator,u.name creatorName FROM tournaments t LEFT JOIN event_details d ON d.event_id=t.id LEFT JOIN users u ON u.id=d.creator WHERE t.active=1 ORDER BY t.ends_at>? DESC,t.starts_at DESC LIMIT 100').all(Date.now()).map(t=>({...t,kind:t.kind||'event',participants:db.prepare('SELECT COUNT(DISTINCT p1) n FROM matches WHERE tournament=?').get(t.id).n,myMatch:u?db.prepare('SELECT id,state FROM matches WHERE tournament=? AND p1=? ORDER BY started_at LIMIT 1').get(t.id,u.id):null,settled:!!db.prepare('SELECT 1 FROM event_settled WHERE event_id=?').get(t.id)})));
 }
 const leaderboard=path.match(/^\/api\/features\/competitions\/([^/]+)\/leaderboard$/);
 if(leaderboard&&method==='GET'){const event=db.prepare('SELECT * FROM tournaments WHERE id=? AND active=1').get(leaderboard[1]);fail(!event,'رویداد پیدا نشد.',404);settleCompetitions(db);return done({event,rows:competitionRanks(db,event.id),settled:!!db.prepare('SELECT 1 FROM event_settled WHERE event_id=?').get(event.id)});}
 fail(!u,'ابتدا وارد بازی شوید.',401);
 if(path==='/api/features/my-rank'&&method==='GET')return done(rankedPlayers(db,{category:url.searchParams.get('category')||'',period:url.searchParams.get('period')||'all',metric:url.searchParams.get('metric')||'xp',country:url.searchParams.get('country')||'',city:url.searchParams.get('city')||'',userId:u.id})[0]||null);
 if(path==='/api/features/competitions'&&method==='POST'){
  const c=db.prepare('SELECT * FROM categories WHERE id=? AND active=1').get(b.category);fail(!c,'موضوع معتبر نیست.');fail(c.safety&&!setting('safetyReviewed'),'موضوع ایمنی هنوز برای رقابت تأیید نشده است.');fail(db.prepare("SELECT COUNT(*) n FROM questions WHERE category=? AND status='approved'").get(c.id).n<7,'برای چالش حداقل هفت سؤال منتشرشده لازم است.');
  fail(db.prepare('SELECT COUNT(*) n FROM event_details d JOIN tournaments t ON t.id=d.event_id WHERE d.creator=? AND t.ends_at>? AND t.active=1').get(u.id,Date.now()).n>=3,'حداکثر سه چالش فعال می‌توانی داشته باشی.');
  const hours=Number(b.hours);fail(![1,6,12,24,48,72].includes(hours),'مدت چالش معتبر نیست.');const id=randomUUID(),title=text(b.title,3,80),now=Date.now();transaction(()=>{db.prepare('INSERT INTO tournaments VALUES (?,?,?,?,?,?,1)').run(id,title,c.id,now,now+hours*3600000,text(b.description||'',0,500));db.prepare('INSERT INTO event_details VALUES (?,?,?,?)').run(id,u.id,'open',JSON.stringify(game.snapshot(c.id)));audit(u.id,'create-open-challenge',id);});return done({id});
 }
 if(path==='/api/features/rewards'&&method==='GET')return done({...rewardState(db,u.id),serverTime:Date.now(),prizes:[10,15,20,25,30,40]});
 if(path==='/api/features/rewards/claim'&&method==='POST'){
  fail(!['daily','chest'].includes(b.kind),'نوع هدیه معتبر نیست.');let coins=0;
  transaction(()=>{const state=rewardState(db,u.id);let sequence;
   if(b.kind==='daily'){fail(Date.now()<state.nextDailyAt,'هدیهٔ امروز را دریافت کرده‌ای؛ شمارش معکوس را ببین.');sequence=db.prepare("SELECT COUNT(*) n FROM reward_claims WHERE user_id=? AND kind='daily'").get(u.id).n+1;coins=[10,15,20,25,30,40][randomInt(6)];}
   else{fail(state.chestsAvailable<1,'برای صندوق، پنج مسابقه با حداقل سه پاسخ درست در هر مسابقه کامل کن.');sequence=state.chestsClaimed+1;coins=50;}
   db.prepare('INSERT INTO reward_claims VALUES (?,?,?,?,?)').run(u.id,b.kind,sequence,coins,Date.now());db.prepare('UPDATE users SET coins=coins+? WHERE id=?').run(coins,u.id);audit(u.id,'claim-'+b.kind,String(sequence));
  });return done({coins,...rewardState(db,u.id)});
 }
 if(path==='/api/features/store'&&method==='GET'){fail(!setting('shopEnabled'),'فروشگاه موقتاً غیرفعال است.',403);return done({items:ITEMS,owned:db.prepare('SELECT item FROM inventory WHERE user_id=?').all(u.id).map(x=>x.item),equipped:db.prepare('SELECT frame,title FROM cosmetics WHERE user_id=?').get(u.id)||{frame:'',title:''},coins:db.prepare('SELECT coins FROM users WHERE id=?').get(u.id).coins});}
 if(path==='/api/features/store/buy'&&method==='POST'){
  fail(!setting('shopEnabled'),'فروشگاه غیرفعال است.',403);const item=ITEMS.find(x=>x.id===b.item);fail(!item,'آیتم پیدا نشد.');transaction(()=>{fail(db.prepare('SELECT 1 FROM inventory WHERE user_id=? AND item=?').get(u.id,item.id),'این آیتم را داری.');fail(!db.prepare('UPDATE users SET coins=coins-? WHERE id=? AND coins>=?').run(item.price,u.id,item.price).changes,'سکهٔ کافی نداری.');db.prepare('INSERT INTO inventory VALUES (?,?)').run(u.id,item.id);});return done({ok:true});
 }
 if(path==='/api/features/store/equip'&&method==='POST'){
  const item=ITEMS.find(x=>x.id===b.item);fail(!item||!['frame','title'].includes(item.kind),'این آیتم قابل پوشیدن نیست.');fail(!db.prepare('SELECT 1 FROM inventory WHERE user_id=? AND item=?').get(u.id,item.id),'ابتدا آیتم را تهیه کن.');db.prepare('INSERT OR IGNORE INTO cosmetics(user_id) VALUES (?)').run(u.id);db.prepare(`UPDATE cosmetics SET ${item.kind}=? WHERE user_id=?`).run(b.remove?'':item.id,u.id);return done({ok:true});
 }
 const achievements=path.match(/^\/api\/features\/achievements\/([^/]+)$/);
 if(achievements&&method==='GET'){
  const target=db.prepare('SELECT * FROM users WHERE id=? AND banned=0').get(achievements[1]);fail(!target||game.blocked(u.id,target.id),'بازیکن پیدا نشد.',404);fail(target.private&&target.id!==u.id&&u.role!=='admin'&&!db.prepare("SELECT 1 FROM follows WHERE user_id=? AND target_id=? AND status='approved'").get(u.id,target.id),'حساب خصوصی است.',403);
  const games=db.prepare("SELECT COUNT(*) n FROM matches WHERE (p1=? OR p2=?) AND state='finished'").get(target.id,target.id).n,posts=db.prepare("SELECT COUNT(*) n FROM posts WHERE user_id=? AND status='approved'").get(target.id).n;
  const badges=[{id:'first-game',name:'اولین قدم',icon:'bolt',description:'یک مسابقه را کامل کن',unlocked:games>=1},{id:'ten-games',name:'اهل تمرین',icon:'target',description:'ده مسابقه را کامل کن',unlocked:games>=10},{id:'first-cup',name:'قهرمان رقابت',icon:'trophy',description:'اولین جام را به دست بیاور',unlocked:target.cups>=1},{id:'experience',name:'راوی تجربه',icon:'feed',description:'یک پست تأییدشده داشته باش',unlocked:posts>=1},{id:'week',name:'هفت روز همراه',icon:'fire',description:'هفت روز پیوسته بازی کن',unlocked:target.streak>=7},{id:'thousand',name:'هزار قدم یادگیری',icon:'medal',description:'هزار امتیاز تجربه بگیر',unlocked:target.xp>=1000}];
  return done({badges,awards:db.prepare('SELECT a.*,t.title FROM event_awards a JOIN tournaments t ON t.id=a.event_id WHERE a.user_id=? ORDER BY t.ends_at DESC').all(target.id),cosmetics:db.prepare('SELECT frame,title FROM cosmetics WHERE user_id=?').get(target.id)||{}});
 }
 return false;
}
