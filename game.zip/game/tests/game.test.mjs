import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {openDB} from '../server/db.mjs';
import {Game} from '../server/game.mjs';
function setup(){mkdirSync('audit/test-runs',{recursive:true});const dir=mkdtempSync(resolve('audit/test-runs/game-')),db=openDB(dir);for(const id of ['one','two'])db.prepare('INSERT INTO users(id,name,avatar,created_at) VALUES (?,?,?,?)').run(id,id,'/assets/avatars/1.svg',Date.now());return {db,game:new Game(db),dir};}
test('Real two-player match: identical questions, hidden correct answers, duplicate scoring rejected, reward once',()=>{
 const {db,game}=setup();try{
  const waiting=game.create('one','electric','private');assert.equal(waiting.state,'waiting');assert.equal(waiting.question,null);
  const started=game.join('two',waiting.code),id=started.id;assert.equal(started.players.length,2);
  assert.equal(started.state,'intro');assert.equal(started.question,null);assert.throws(()=>game.answer(id,'one',0,0));db.prepare('UPDATE matches SET round_at=? WHERE id=?').run(Date.now()-1,id);
  for(let round=0;round<7;round++){
   const a=game.view(id,'one'),b=game.view(id,'two');assert.deepEqual(a.question.options,b.question.options);assert.equal(a.question.correct,undefined);assert.equal(a.question.explanation,undefined);
   const q=JSON.parse(game.get(id).questions)[round];game.answer(id,'one',round,q.correct);assert.throws(()=>game.answer(id,'one',round,q.correct));game.answer(id,'two',round,(q.correct+1)%4);
   assert.equal(game.view(id,'two').question.correct,q.correct);db.prepare('UPDATE matches SET round_at=? WHERE id=?').run(Date.now()-5000,id);game.advance(game.get(id));
  }
  const finish=game.view(id,'one');assert.equal(finish.state,'finished');assert.equal(finish.result,'win');assert.equal(game.view(id,'two').result,'loss');assert.equal(finish.firstWin,true);assert.equal(finish.ratingChange,12);assert.equal(game.view(id,'two').ratingChange,-12);assert.equal(finish.history.length,7);assert.ok(finish.players[0].score>=1000);const user=db.prepare("SELECT xp,coins,cups FROM users WHERE id='one'").get();assert.equal(user.cups,1);assert.equal(user.xp,100);game.finish(game.get(id));assert.deepEqual(db.prepare("SELECT xp,coins,cups FROM users WHERE id='one'").get(),user);
 }finally{db.close();}
});
test('Question deletion does not break an in-flight match; safety restricted; deletion persists on restart',()=>{
 const {db,game,dir}=setup();try{assert.throws(()=>game.create('one','safety','private'));const m=game.create('one','electric'),q=JSON.parse(game.get(m.id).questions)[0];db.prepare('DELETE FROM questions WHERE id=?').run(q.id);assert.doesNotThrow(()=>game.answer(m.id,'one',0,(q.correct+1)%4));db.close();const reopened=openDB(dir);assert.equal(reopened.prepare('SELECT id FROM questions WHERE id=?').get(q.id),undefined);reopened.close();}catch(e){try{db.close();}catch{}throw e;}
});
