import {randomUUID,randomBytes,scryptSync,timingSafeEqual} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
export function migratePlatform(db){
 db.exec(`CREATE TABLE IF NOT EXISTS player_details(user_id TEXT PRIMARY KEY REFERENCES users(id),country TEXT DEFAULT '',city TEXT DEFAULT '',occupation TEXT DEFAULT '',specialty TEXT DEFAULT '',age INTEGER,rating INTEGER DEFAULT 1200,history_public INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS match_details(match_id TEXT PRIMARY KEY REFERENCES matches(id),intro_until INTEGER DEFAULT 0,forfeit TEXT,rating1 INTEGER DEFAULT 0,rating2 INTEGER DEFAULT 0,first_win TEXT);
 CREATE TABLE IF NOT EXISTS bot_profiles(user_id TEXT PRIMARY KEY REFERENCES users(id),accuracy REAL DEFAULT .65,delay_min INTEGER DEFAULT 2000,delay_max INTEGER DEFAULT 8000,active INTEGER DEFAULT 1);
 CREATE TABLE IF NOT EXISTS bot_answers(match_id TEXT,round INTEGER,user_id TEXT,at INTEGER,choice INTEGER,PRIMARY KEY(match_id,round,user_id));
 CREATE TABLE IF NOT EXISTS notification_links(id TEXT PRIMARY KEY,link TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS message_tombstones(id TEXT PRIMARY KEY,deleted_at INTEGER);
 CREATE TABLE IF NOT EXISTS support_tickets(id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),subject TEXT,body TEXT,media TEXT DEFAULT '',status TEXT DEFAULT 'open',reply TEXT DEFAULT '',created_at INTEGER);
 CREATE TABLE IF NOT EXISTS resource_library(id TEXT PRIMARY KEY,path TEXT UNIQUE,title TEXT,mime TEXT,size INTEGER,owner TEXT REFERENCES users(id),created_at INTEGER);
 CREATE TABLE IF NOT EXISTS org_spaces(slug TEXT PRIMARY KEY,name TEXT,description TEXT DEFAULT '',logo TEXT DEFAULT '',banner TEXT DEFAULT '',categories TEXT DEFAULT '[]',kids INTEGER DEFAULT 0,active INTEGER DEFAULT 1);
 CREATE TABLE IF NOT EXISTS scheduled_posts(id TEXT PRIMARY KEY,author TEXT REFERENCES users(id),category TEXT,body TEXT,media TEXT DEFAULT '',publish_at INTEGER,interval_hours REAL DEFAULT 0,remaining INTEGER DEFAULT 1,status TEXT DEFAULT 'scheduled');
 CREATE TABLE IF NOT EXISTS email_credentials(user_id TEXT PRIMARY KEY REFERENCES users(id),email TEXT UNIQUE,salt TEXT,hash TEXT,verified INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS daily_questions(day TEXT PRIMARY KEY,question TEXT);
 CREATE TABLE IF NOT EXISTS daily_entries(day TEXT,user_id TEXT REFERENCES users(id),started_at INTEGER,choice INTEGER,correct INTEGER,elapsed INTEGER,PRIMARY KEY(day,user_id));
 CREATE TABLE IF NOT EXISTS question_metadata(question_id TEXT PRIMARY KEY REFERENCES questions(id),subcategory TEXT DEFAULT '',language TEXT DEFAULT 'fa',difficulty TEXT DEFAULT 'medium',created_at INTEGER,last_verified INTEGER);
 CREATE TABLE IF NOT EXISTS feed_seen(user_id TEXT REFERENCES users(id) ON DELETE CASCADE,post_id TEXT REFERENCES posts(id) ON DELETE CASCADE,seen_at INTEGER,PRIMARY KEY(user_id,post_id));
 CREATE TABLE IF NOT EXISTS security_flags(id TEXT PRIMARY KEY,user_id TEXT,kind TEXT,detail TEXT,created_at INTEGER,status TEXT DEFAULT 'open');`);
 const defaults={tagline:'هر بازی، یک قدم به جلو',footer:'ساخته‌شده برای یادگیری',siteLogo:'/assets/logo.svg',musicEnabled:true,soundEnabled:true,audioFiles:{},hiddenSections:[],slides:[],languages:[{id:'fa',name:'فارسی',active:true}],botEnabled:true};
 for(const [k,v]of Object.entries(defaults))db.prepare('INSERT OR IGNORE INTO settings VALUES (?,?)').run(k,JSON.stringify(v));
 db.prepare('INSERT OR IGNORE INTO player_details(user_id) SELECT id FROM users').run();
 if(!db.prepare("SELECT 1 FROM settings WHERE key='bots-v1'").get()){
  const names=['آذر','آرمان','مهتاب','دانا','سام','نوا','رایا','پویان','روشن','باران','آوا','کیان','مهر','سپهر','سینا','نیما','ترانه','آراد','مانا','شایان'];
  names.forEach((name,i)=>{const id='computer-'+(i+1);db.prepare("INSERT INTO users(id,name,avatar,role,bio,is_demo,created_at) VALUES (?,?,?,'bot',?,2,?)").run(id,name+' · رایانه‌ای',`/assets/avatars/${i%10+1}.svg`,'حریف رایانه‌ای آموزشی؛ انسان واقعی نیست و رتبه و دنبال‌کنندهٔ انسانی ساختگی ندارد.',Date.now());db.prepare('INSERT INTO player_details(user_id) VALUES (?)').run(id);db.prepare('INSERT INTO bot_profiles(user_id,accuracy) VALUES (?,?)').run(id,[.6,.65,.7,.75,.8][i%5]);});db.prepare("INSERT INTO settings VALUES ('bots-v1','true')").run();
 }
}
export function safeLink(value){return typeof value==='string'&&value.length<=600&&(/^(?:#|\/)(?!\/)/.test(value)||/^https:\/\//.test(value));}
export function platformTick(db){
 const now=Date.now();for(const p of db.prepare("SELECT * FROM scheduled_posts WHERE status='scheduled' AND publish_at<=? LIMIT 30").all(now)){
  db.exec('BEGIN IMMEDIATE');try{db.prepare("INSERT INTO posts(id,user_id,category,body,media,status,created_at) VALUES (?,?,?,?,?,'approved',?)").run(randomUUID(),p.author,p.category,p.body,p.media,now);if(p.remaining>1&&p.interval_hours>0)db.prepare('UPDATE scheduled_posts SET publish_at=?,remaining=remaining-1 WHERE id=?').run(Math.max(now,p.publish_at)+p.interval_hours*3600000,p.id);else db.prepare("UPDATE scheduled_posts SET status='published',remaining=0 WHERE id=?").run(p.id);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
 }
}
export async function platformRoute(c){
 const {path,method,url,b,u,db,game,res,json,fail,text,media,audit,transaction,notice,notify,presence,data,newSession,pub,limited}=c;
 if(!path.startsWith('/api/platform/'))return false;const done=v=>{json(res,v);return true;},now=Date.now();
 if(path==='/api/platform/auth/email'&&method==='POST'){
  limited('email-auth:'+c.ip,12,900000);const email=String(b.email||'').trim().toLowerCase(),password=b.password;fail(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254,'ایمیل معتبر وارد کنید.');fail(typeof password!=='string'||password.length<10||password.length>128,'رمز باید بین ۱۰ تا ۱۲۸ نویسه باشد.');
  let account=db.prepare('SELECT * FROM email_credentials WHERE email=?').get(email);
  if(b.register){fail(account||db.prepare('SELECT 1 FROM users WHERE lower(email)=?').get(email),'برای این ایمیل حساب وجود دارد؛ از ورود همان حساب استفاده کنید.');const id=randomUUID(),salt=randomBytes(16).toString('hex'),hash=scryptSync(password,salt,64).toString('hex');const name=text(b.name,2,40);transaction(()=>{db.prepare('INSERT INTO users(id,name,avatar,email,created_at) VALUES (?,?,?,?,?)').run(id,name,'/assets/avatars/1.svg',email,now);db.prepare('INSERT INTO email_credentials VALUES (?,?,?,?,0)').run(id,email,salt,hash);db.prepare('INSERT INTO player_details(user_id) VALUES (?)').run(id);});account={user_id:id};}
  else{const salt=account?.salt||'not-a-real-account';const hash=scryptSync(password,salt,64);fail(!account||!timingSafeEqual(hash,Buffer.from(account.hash,'hex')),'ایمیل یا رمز صحیح نیست.',401);}
  const user=db.prepare('SELECT * FROM users WHERE id=?').get(account.user_id);fail(user.banned,'حساب غیرفعال است.',403);return done({user:pub(user,true),csrf:newSession(res,user.id)});
 }
 if(path==='/api/platform/spaces'&&method==='GET')return done(db.prepare('SELECT * FROM org_spaces WHERE active=1').all().map(x=>({...x,categories:JSON.parse(x.categories)})));
 if(path==='/api/platform/lobby'&&method==='GET'){
  const real=[...presence].filter(([id,t])=>now-t<45000&&id!==u?.id).map(([id])=>db.prepare('SELECT u.id,u.name,u.avatar,d.country,d.city,d.occupation FROM users u LEFT JOIN player_details d ON d.user_id=u.id WHERE u.id=? AND u.banned=0 AND u.is_demo=0 AND u.private=0').get(id)).filter(x=>x&&!game.blocked(u?.id||'',x.id)).slice(0,6);
  const bots=JSON.parse(db.prepare("SELECT value FROM settings WHERE key='botEnabled'").get()?.value||'true')?db.prepare('SELECT u.id,u.name,u.avatar,b.accuracy FROM bot_profiles b JOIN users u ON u.id=b.user_id WHERE b.active=1 AND u.banned=0 ORDER BY RANDOM() LIMIT 3').all():[];
  const queue=[...game.queue].filter(([id])=>id!==u?.id).map(([id,q])=>{const person=db.prepare('SELECT id,name,avatar,private FROM users WHERE id=? AND banned=0').get(id);return person&&!person.private&&!game.blocked(u?.id||'',id)?{...person,category:q.category}:null;}).filter(Boolean).slice(0,12);return done({real,bots,queue});
 }
 fail(!u,'ابتدا وارد شوید.',401);
 if(path==='/api/platform/profile'&&method==='PATCH'){
  const values=['country','city','occupation','specialty'].map(k=>text(b[k]||'',0,70));const age=b.age===''||b.age==null?null:Number(b.age);fail(age!==null&&(!Number.isInteger(age)||age<4||age>110),'سن از ۴ تا ۱۱۰ سال باشد.');
  db.prepare('INSERT OR IGNORE INTO player_details(user_id) VALUES (?)').run(u.id);db.prepare('UPDATE player_details SET country=?,city=?,occupation=?,specialty=?,age=?,history_public=? WHERE user_id=?').run(...values,age,b.historyPublic?1:0,u.id);return done({ok:true});
 }
 const profile=path.match(/^\/api\/platform\/profile\/([^/]+)$/);
 if(profile&&method==='GET'){
  const target=db.prepare('SELECT * FROM users WHERE id=? AND banned=0').get(profile[1]);fail(!target||game.blocked(u.id,target.id),'کاربر پیدا نشد.',404);const own=target.id===u.id,visible=own||u.role==='admin'||!target.private||!!db.prepare("SELECT 1 FROM follows WHERE user_id=? AND target_id=? AND status='approved'").get(u.id,target.id);const details=db.prepare('SELECT * FROM player_details WHERE user_id=?').get(target.id)||{};const {age,...publicDetails}=details;
  const history=visible&&(own||details.history_public)?db.prepare("SELECT m.id,m.category,m.mode,m.score1,m.score2,m.p1,m.p2,m.finished_at,a.name name1,z.name name2 FROM matches m JOIN users a ON a.id=m.p1 LEFT JOIN users z ON z.id=m.p2 WHERE (m.p1=? OR m.p2=?) AND m.state='finished' ORDER BY m.finished_at DESC LIMIT 20").all(target.id,target.id).map(m=>({...m,result:!m.p2?'practice':m.score1===m.score2?'draw':((m.p1===target.id?m.score1:m.score2)>(m.p1===target.id?m.score2:m.score1)?'win':'loss')})):[];
  return done({details:visible?{...publicDetails,...(own?{age}:{})}:{},online:now-(presence.get(target.id)||0)<45000,history,following:visible?db.prepare("SELECT u.id,u.name,u.avatar FROM follows f JOIN users u ON u.id=f.target_id WHERE f.user_id=? AND f.status='approved' AND u.banned=0 LIMIT 100").all(target.id):[],interests:visible?JSON.parse(target.interests):[]});
 }
 if(path==='/api/platform/bot-match'&&method==='POST'){fail(JSON.parse(db.prepare("SELECT value FROM settings WHERE key='botEnabled'").get()?.value||'true')===false,'حریف رایانه‌ای غیرفعال است.');const bot=b.bot?db.prepare('SELECT user_id FROM bot_profiles WHERE user_id=? AND active=1').get(b.bot):db.prepare('SELECT user_id FROM bot_profiles WHERE active=1 ORDER BY RANDOM() LIMIT 1').get();fail(!bot,'حریف رایانه‌ای پیدا نشد.');return done(game.create(u.id,b.category,'computer',bot.user_id));}
 if(path==='/api/platform/challenge-user'&&method==='POST'){
  const target=db.prepare('SELECT * FROM users WHERE id=? AND banned=0 AND is_demo=0').get(b.user);fail(!target||target.id===u.id||game.blocked(u.id,target.id),'بازیکن در دسترس نیست.');const m=game.create(u.id,b.category,'private');notice(target.id,u.name+' تو را به رقابت دعوت کرد','کد ورود: '+m.code,'#challenge/'+m.code);return done(m);
 }
 const rematch=path.match(/^\/api\/platform\/rematch\/([^/]+)$/);
 if(rematch&&method==='POST'){const old=game.get(rematch[1]);fail(!old||![old.p1,old.p2].includes(u.id)||old.state!=='finished','مسابقهٔ پایان‌یافته پیدا نشد.');const other=old.p1===u.id?old.p2:old.p1;fail(!other,'این مسابقه حریف نداشت.');if(old.mode==='computer')return done(game.create(u.id,old.category,'computer',other));fail(game.blocked(u.id,other),'این بازیکن در دسترس نیست.');const m=game.create(u.id,old.category,'private');notice(other,'درخواست مبارزهٔ دوباره',u.name+' می‌خواهد دوباره رقابت کند.','#challenge/'+m.code);return done(m);}
 const message=path.match(/^\/api\/platform\/messages\/([^/]+)$/);
 if(message&&method==='DELETE'){const m=db.prepare('SELECT * FROM messages WHERE id=?').get(message[1]);fail(!m||m.sender!==u.id,'فقط پیام خودت را می‌توانی حذف کنی.',403);transaction(()=>{db.prepare("UPDATE messages SET body='این پیام حذف شده است.',media='' WHERE id=?").run(m.id);db.prepare('INSERT OR IGNORE INTO message_tombstones VALUES (?,?)').run(m.id,now);});notify(m.recipient,'message',{sender:u.id,deleted:true});return done({ok:true});}
 if(path==='/api/platform/support'&&method==='POST'){const id=randomUUID();db.prepare('INSERT INTO support_tickets(id,user_id,subject,body,media,created_at) VALUES (?,?,?,?,?,?)').run(id,u.id,text(b.subject,3,120),text(b.body,5,4000),media(b.media,u.id),now);for(const admin of db.prepare("SELECT id FROM users WHERE role='admin'").all())notice(admin.id,'پیام تازه به پشتیبانی',u.name+': '+b.subject,'#admin');return done({id});}
 if(path==='/api/platform/support'&&method==='GET')return done(db.prepare('SELECT * FROM support_tickets WHERE user_id=? ORDER BY created_at DESC LIMIT 100').all(u.id));
 if(path.startsWith('/api/platform/admin/')){
  fail(u.role!=='admin','فقط مدیر دسترسی دارد.',403);
  if(path==='/api/platform/admin/support'&&method==='GET')return done(db.prepare('SELECT t.*,u.name FROM support_tickets t JOIN users u ON u.id=t.user_id ORDER BY created_at DESC LIMIT 300').all());
  if(path==='/api/platform/admin/support'&&method==='PATCH'){const t=db.prepare('SELECT * FROM support_tickets WHERE id=?').get(b.id);fail(!t,'پیام پیدا نشد.');const reply=text(b.reply,2,4000);db.prepare("UPDATE support_tickets SET reply=?,status='answered' WHERE id=?").run(reply,t.id);notice(t.user_id,'پاسخ پشتیبانی',reply.slice(0,500),'#support');return done({ok:true});}
  if(path==='/api/platform/admin/brand'&&method==='PATCH'){
   const updates={};for(const k of ['siteTitle','tagline','footer','welcome'])if(k in b)updates[k]=text(b[k],1,160);
   if('siteLogo'in b)updates.siteLogo=b.siteLogo==='/assets/logo.svg'?b.siteLogo:media(b.siteLogo,u.id);
   for(const k of ['musicEnabled','soundEnabled','botEnabled'])if(k in b){fail(typeof b[k]!=='boolean','تنظیم نامعتبر');updates[k]=b[k];}
   if(b.hiddenSections){fail(!Array.isArray(b.hiddenSections),'بخش‌ها معتبر نیستند.');updates.hiddenSections=b.hiddenSections.filter(x=>['feed','messages','shop','events','rewards','learn','users','suggest'].includes(x));}
   if(b.audioFiles){updates.audioFiles={};for(const k of ['music','click','correct','wrong','warning'])if(b.audioFiles[k])updates.audioFiles[k]=media(b.audioFiles[k],u.id,['audio/']);}
   if(b.slides){fail(!Array.isArray(b.slides)||b.slides.length>30,'حداکثر ۳۰ اسلاید مجاز است.');updates.slides=b.slides.map(x=>{fail(!safeLink(x.link),'لینک اسلاید باید داخلی یا HTTPS باشد.');return {image:media(x.image,u.id),title:text(x.title||'',0,100),link:x.link};});}
   transaction(()=>{for(const [k,v]of Object.entries(updates))db.prepare('INSERT INTO settings VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k,JSON.stringify(v));});audit(u.id,'brand-settings');return done({ok:true});
  }
  if(path==='/api/platform/admin/resources'&&method==='GET')return done(db.prepare('SELECT * FROM resource_library ORDER BY created_at DESC').all());
  if(path==='/api/platform/admin/resources'&&method==='POST'){
   const types={'application/pdf':['.pdf',x=>x.subarray(0,5).toString()==='%PDF-'],'application/vnd.openxmlformats-officedocument.wordprocessingml.document':['.docx',x=>x[0]===80&&x[1]===75],'application/msword':['.doc',x=>x.subarray(0,4).equals(Buffer.from([208,207,17,224]))]};
   const type=types[b.mime];fail(!type,'برای ویدئو و صدا از بارگذاری رسانه استفاده کنید؛ این ورودی PDF یا Word می‌پذیرد.');fail(typeof b.data!=='string'||b.data.length>22*1024*1024,'فایل بیش از حد بزرگ است.');const bytes=Buffer.from(b.data,'base64');fail(bytes.length>15*1024*1024||!type[1](bytes),'فایل معتبر نیست یا بیش از ۱۵ مگابایت است.');const id=randomUUID(),path='/uploads/'+id+type[0];writeFileSync(resolve(data,'uploads',id+type[0]),bytes);transaction(()=>{db.prepare('INSERT INTO uploads VALUES (?,?,?,?,?,?)').run(id,u.id,path,b.mime,bytes.length,now);db.prepare('INSERT INTO resource_library VALUES (?,?,?,?,?,?,?)').run(id,path,text(b.title,2,140),b.mime,bytes.length,u.id,now);});return done({path});
  }
  if(path==='/api/platform/admin/resources/register'&&method==='POST'){const file=media(b.path,u.id,['audio/','video/','image/']),f=db.prepare('SELECT * FROM uploads WHERE path=?').get(file);db.prepare('INSERT OR IGNORE INTO resource_library VALUES (?,?,?,?,?,?,?)').run(f.id,file,text(b.title,2,140),f.mime,f.size,u.id,now);return done({path:file});}
  if(path==='/api/platform/admin/spaces'&&method==='GET')return done(db.prepare('SELECT * FROM org_spaces').all());
  if(path==='/api/platform/admin/spaces'&&method==='POST'){fail(!/^[a-z][a-z0-9-]{2,40}$/.test(b.slug||''),'شناسهٔ صفحه ۳ تا ۴۱ حرف لاتین، عدد یا خط تیره باشد.');fail(!Array.isArray(b.categories)||b.categories.some(id=>!db.prepare('SELECT 1 FROM categories WHERE id=?').get(id)),'موضوع‌های صفحه معتبر نیستند.');db.prepare('INSERT INTO org_spaces VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(slug) DO UPDATE SET name=excluded.name,description=excluded.description,logo=excluded.logo,banner=excluded.banner,categories=excluded.categories,kids=excluded.kids,active=excluded.active').run(b.slug,text(b.name,2,100),text(b.description||'',0,500),media(b.logo,u.id),media(b.banner,u.id),JSON.stringify(b.categories),Number(!!b.kids),b.active===false?0:1);return done({slug:b.slug});}
  if(path==='/api/platform/admin/schedules'&&method==='GET')return done(db.prepare('SELECT s.*,u.name FROM scheduled_posts s JOIN users u ON u.id=s.author ORDER BY publish_at DESC').all());
  if(path==='/api/platform/admin/schedules'&&method==='POST'){fail(!db.prepare('SELECT 1 FROM categories WHERE id=? AND active=1').get(b.category),'موضوع معتبر نیست.');const at=Number(b.publishAt),repeat=Number(b.intervalHours||0),count=Number(b.count||1);fail(!Number.isFinite(at)||at<=now||!Number.isFinite(repeat)||repeat<0||repeat>8760||!Number.isInteger(count)||count<1||count>100||count>1&&repeat<1/6,'زمان یا تکرار معتبر نیست؛ حداقل فاصلهٔ تکرار ۱۰ دقیقه است.');const author=b.author||u.id;fail(!db.prepare("SELECT 1 FROM users WHERE id=? AND (role='admin' OR is_demo>0)").get(author),'فقط حساب مدیر یا حساب نمونهٔ مشخص‌شده مجاز است.');const id=randomUUID();db.prepare('INSERT INTO scheduled_posts VALUES (?,?,?,?,?,?,?,?,?)').run(id,author,b.category,text(b.body,3,4000),media(b.media,u.id),at,repeat,count,'scheduled');return done({id});}
  if(path==='/api/platform/admin/schedules'&&method==='DELETE'){db.prepare("UPDATE scheduled_posts SET status='cancelled' WHERE id=?").run(b.id);return done({ok:true});}
  if(path==='/api/platform/admin/bots'&&method==='GET')return done(db.prepare('SELECT u.id,u.name,u.avatar,d.country,d.city,b.accuracy,b.active FROM bot_profiles b JOIN users u ON u.id=b.user_id LEFT JOIN player_details d ON d.user_id=u.id').all());
  if(path==='/api/platform/admin/bots'&&method==='PATCH'){fail(!db.prepare('SELECT 1 FROM bot_profiles WHERE user_id=?').get(b.id),'حریف رایانه‌ای پیدا نشد.');const accuracy=Number(b.accuracy);fail(!Number.isFinite(accuracy)||accuracy<.2||accuracy>.95,'دقت بین ۲۰ تا ۹۵ درصد باشد.');transaction(()=>{db.prepare('UPDATE users SET name=? WHERE id=?').run(text(b.name,2,45).replace(/ · رایانه‌ای$/,'')+' · رایانه‌ای',b.id);db.prepare('UPDATE player_details SET country=?,city=? WHERE user_id=?').run(text(b.country||'',0,70),text(b.city||'',0,70),b.id);db.prepare('UPDATE bot_profiles SET accuracy=?,active=? WHERE user_id=?').run(accuracy,Number(!!b.active),b.id);});return done({ok:true});}
  if(path==='/api/platform/admin/question-stats'&&method==='GET')return done(db.prepare("SELECT q.id,q.title,q.category,COUNT(a.question_id) played,ROUND(100.0*AVG(a.correct),1) accuracy,ROUND(AVG(a.elapsed)/1000,2) averageSeconds,(SELECT COUNT(*) FROM reports r WHERE r.kind='question' AND r.target=q.id) reports FROM questions q LEFT JOIN answers a ON a.question_id=q.id GROUP BY q.id ORDER BY played DESC LIMIT 1000").all());
 }
 return false;
}
