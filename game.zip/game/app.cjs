'use strict';
// CommonJS entry point for cPanel/Passenger; the application remains ESM.
const {resolve}=require('node:path');
const {pathToFileURL}=require('node:url');
const [major,minor]=process.versions.node.split('.').map(Number);
if(!((major===22&&minor>=13)||major===24)){
 console.error('Gamify needs Node 22.13+ (22.x) or Node 24.x, with node:sqlite enabled.');process.exit(1);
}
try{process.loadEnvFile(resolve(__dirname,'.env'));}catch(e){if(e.code!=='ENOENT')throw e;}
if(typeof PhusionPassenger!=='undefined')PhusionPassenger.configure({autoInstall:false});
import(pathToFileURL(resolve(__dirname,'server/index.mjs')).href).then(({createApp})=>{
 const app=createApp();
 app.server.on('error',error=>{console.error('Server startup failed:',error.message);process.exitCode=1;app.close();});
 if(typeof PhusionPassenger!=='undefined')app.server.listen('passenger');
 else app.server.listen(Number(process.env.PORT)||3000,process.env.HOST||'127.0.0.1');
 app.server.once('listening',()=>console.log('Gamify ready; health endpoint: /health; private owner key is in DATA_DIR/admin-key.txt unless ADMIN_KEY is configured.'));
 let stopping=false;for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{if(stopping)return;stopping=true;app.close().then(()=>process.exit(0));});
}).catch(error=>{console.error('Cannot start Gamify:',error.message);process.exitCode=1;});
