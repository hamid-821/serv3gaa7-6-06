export const S={boot:null,user:null,csrf:'',categories:[],settings:{},route:'home',poll:null,events:null,match:null,queue:false,gameKey:'',sound:localStorage.getItem('gm-sound')!=='off',music:localStorage.getItem('gm-music')!=='off',volume:Number(localStorage.getItem('gm-volume')||.35)};
export const $=(s,root=document)=>root.querySelector(s),$$=(s,root=document)=>[...root.querySelectorAll(s)];
export const h=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const fa=n=>new Intl.NumberFormat('fa-IR').format(n??0);
export const date=t=>new Intl.DateTimeFormat('fa-IR',{year:'numeric',month:'long',day:'numeric'}).format(new Date(t));
export const time=t=>new Intl.DateTimeFormat('fa-IR',{hour:'2-digit',minute:'2-digit'}).format(new Date(t));
export const cat=id=>S.categories.find(c=>c.id===id)||{id,name:'موضوع',icon:'book',color:'#ac8fd6',questionCount:0};
const paths={
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
 grid:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
 bolt:'<path d="m13 2-9 12h7l-1 8 10-13h-8z"/>',
 trophy:'<path d="M7 3h10v6a5 5 0 0 1-10 0zM7 5H3v3a4 4 0 0 0 5 4m9-7h4v3a4 4 0 0 1-5 4M12 14v5m-5 2h10m-8-2h6"/>',
 feed:'<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M7 8h10M7 12h6M7 16h10"/>',
 chat:'<path d="M21 11a9 9 0 0 1-9 9 10 10 0 0 1-4-1l-5 2 1-5a9 9 0 1 1 17-5Z"/><path d="M8 11h.01M12 11h.01M16 11h.01" stroke-width="3"/>',
 book:'<path d="M12 5c-3-3-8-2-10-1v15c3-2 7-2 10 0 3-2 7-2 10 0V4c-3-1-7-2-10 1Zm0 0v14"/>',
 user:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2c0-8 16-8 16 0v2"/>',
 users:'<circle cx="9" cy="8" r="3"/><path d="M2 21v-3c0-6 14-6 14 0v3M16 5c5 0 5 7 0 7m2 3c4 0 4 4 4 6"/>',
 settings:'<path d="m9 3-1 3-3 1 1 3-2 2 2 2-1 3 3 1 1 3h6l1-3 3-1-1-3 2-2-2-2 1-3-3-1-1-3z"/><circle cx="12" cy="12" r="3"/>',
 shield:'<path d="M12 2 3 6v6c0 5 9 10 9 10s9-5 9-10V6z"/><path d="m8 12 3 3 5-6"/>',
 search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
 bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 8-3 8h18s-3-1-3-8M10 21h4"/>',
 chevron:'<path d="m14 6-6 6 6 6"/>',
 arrow:'<path d="M20 12H4m6-6-6 6 6 6"/>',
 globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18M5 7h14M5 17h14"/>',
 flask:'<path d="M9 3h6m-5 0v7L4 20q0 1 2 1h12q2 0 2-1l-6-10V3M7 15h10"/><path d="M10 18h.01M14 12h.01"/>',
 cpu:'<rect x="5" y="5" width="14" height="14" rx="3"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 2v3m6-3v3M9 19v3m6-3v3M2 9h3m-3 6h3m14-6h3m-3 6h3"/>',
 briefcase:'<rect x="3" y="7" width="18" height="14" rx="3"/><path d="M8 7V3h8v4M3 12l9 4 9-4m-9 1v4"/>',
 leaf:'<path d="M20 3c-5 2-12-2-16 5-5 12 14 17 16-5Z M3 22l11-12"/>',
 ball:'<circle cx="12" cy="12" r="9"/><path d="m12 7 5 4-2 6H9l-2-6zm0 0V3m5 8 4-2m-6 8 2 3m-8-3-2 3m0-9L3 9"/>',
 heart:'<path d="M20 5c-3-3-6-1-8 2-2-3-5-5-8-2-5 5 3 12 8 16 5-4 13-11 8-16Z"/>',
 bookmark:'<path d="M6 3h12v19l-6-4-6 4z"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 close:'<path d="m6 6 12 12M6 18 18 6"/>',
 check:'<path d="m4 12 5 5L20 6"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
 volume:'<path d="M11 4 6 8H2v8h4l5 4zM15 8c3 2 3 6 0 8m3-11c5 4 5 10 0 14"/>',
 mute:'<path d="M11 4 6 8H2v8h4l5 4zM16 9l6 6m0-6-6 6"/>',
 music:'<path d="M9 18V5l12-3v14M9 8l12-3"/><ellipse cx="6" cy="18" rx="3" ry="3"/><ellipse cx="18" cy="16" rx="3" ry="3"/>',
 image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="2"/><path d="m21 16-6-6L4 21"/>',
 send:'<path d="m22 2-7 20-4-9L2 9zm-11 11L22 2"/>',
 fire:'<path d="M12 2c2 5-3 6 0 10 2-2 4-3 5-6 10 12 2 17-5 16-7 0-13-8-5-15-1 5 2 6 2 6-2-5 4-7 3-11Z"/>',
 coin:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="6"/><path d="m13 7-4 6h4l-1 4 4-7h-4z"/>',
 crown:'<path d="m2 5 5 5 5-7 5 7 5-5-3 13H5zm3 16h14"/>',
 medal:'<circle cx="12" cy="9" r="6"/><path d="m8 14-3 8 7-3 7 3-3-8m-4-8 1 2 2 .5-1.5 1.5.5 2-2-1-2 1 .5-2L9 8.5l2-.5z"/>',
 spark:'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5zM20 2v4m-2-2h4"/>',
 play:'<path d="m8 4 13 8-13 8z"/>',
 menu:'<path d="M3 6h18M3 12h18M3 18h18"/>',
 gift:'<rect x="3" y="8" width="18" height="5" rx="1"/><path d="M5 13v8h14v-8M12 8v13M12 8C1 8 5-2 12 8c7-10 11 0 0 0"/>',
 target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
 lock:'<rect x="4" y="10" width="16" height="12" rx="3"/><path d="M8 10V6a4 4 0 0 1 8 0v4m-4 5v3"/>',
 logout:'<path d="M9 4H3v16h6m6-13 5 5-5 5m-7-5h12"/>',
 edit:'<path d="m4 16 12-12q4-3 5 2L9 19l-6 2zM14 6l4 4"/>',
 flag:'<path d="M4 22V3c6-5 10 5 16 0v12c-6 5-10-5-16 0"/>',
 chart:'<path d="M4 3v18h18M8 16v-4m5 4V8m5 8V5"/>',
 download:'<path d="M12 3v12m-5-5 5 5 5-5M3 16v5h18v-5"/>',
 refresh:'<path d="M3 11a9 9 0 0 1 16-6l2 3m0-6v6h-6M21 13A9 9 0 0 1 5 19l-2-3m0 6v-6h6"/>',
 shop:'<path d="m4 3-2 6c0 4 5 4 5 0 0 4 5 4 5 0 0 4 5 4 5 0 0 4 5 4 5 0l-2-6ZM4 12v9h16v-9M9 21v-6h6v6"/>',
 link:'<path d="m10 14 4-4m-7 4-2 2a4 4 0 0 0 6 6l5-5a4 4 0 0 0-1-6m2-1 2-2a4 4 0 0 0-6-6L8 7a4 4 0 0 0 1 6"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
 headphones:'<path d="M3 15v-3a9 9 0 0 1 18 0v3"/><rect x="2" y="12" width="5" height="9" rx="2"/><rect x="17" y="12" width="5" height="9" rx="2"/>'
};
export const icon=(name,cls='')=>`<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||paths.spark}</svg>`;
export const avatar=(user,size='')=>`<img class="avatar ${size} ${user?.cosmetics?.frame==='frame-gold'?'frame-gold':user?.cosmetics?.frame==='frame-violet'?'frame-violet':''}" src="${h(user?.avatar||'/assets/avatars/1.svg')}" alt="آواتار ${h(user?.name||'بازیکن')}" width="48" height="48">`;
export const categoryOptions=(selected='',all=false)=>`${all?'<option value="">همهٔ موضوع‌ها</option>':''}${S.categories.map(c=>`<option value="${h(c.id)}" ${c.id===selected?'selected':''}>${h(c.name)}</option>`).join('')}`;
export function setBoot(data){S.boot=data;S.user=data.user;S.csrf=data.csrf||'';S.categories=data.categories;S.settings=data.settings;document.title=S.settings.siteTitle||'گیمیفای ۲';}
export async function api(path,method='GET',body){let r;try{r=await fetch('/api'+path,{method,headers:{'Content-Type':'application/json',...(S.csrf?{'X-CSRF-Token':S.csrf}:{})},...(method!=='GET'?{body:JSON.stringify(body||{})}:{}),signal:AbortSignal.timeout(20000)});}catch{throw new Error('ارتباط برقرار نشد. اینترنت یا اجرای سرور را بررسی کن.');}const data=await r.json();if(!r.ok){const e=new Error(data.error||'خطا در دریافت اطلاعات');e.status=r.status;throw e;}return data;}
export function toast(message,error=false){const el=document.createElement('div');el.className='toast '+(error?'error':'');el.innerHTML=icon(error?'info':'check')+`<span>${h(message)}</span>`;const dialog=$('#modal');if(dialog?.open){const area=dialog.querySelector('.modal-body');area?.querySelector('.modal-alert')?.remove();const alert=document.createElement('div');alert.className='modal-alert '+(error?'':'success');alert.setAttribute('role',error?'alert':'status');alert.innerHTML=el.innerHTML;area?.prepend(alert);alert.scrollIntoView({block:'nearest'});setTimeout(()=>alert.remove(),9000);}else $('#toasts').append(el);setTimeout(()=>el.remove(),5000);}
export const empty=(title,desc='',ic='spark')=>`<div class="empty"><span class="empty-icon">${icon(ic)}</span><h3>${h(title)}</h3><p>${h(desc)}</p></div>`;
export const head=(title,desc,action='')=>`<div class="page-heading"><div><h1>${title}</h1><p>${desc}</p></div>${action}</div>`;
export function modal(title,body,wide=false){const d=$('#modal');d.innerHTML=`<header class="modal-head"><h2 id="modal-title">${h(title)}</h2><button class="icon-btn" data-a="close-modal" aria-label="بستن">${icon('close')}</button></header><div class="modal-body">${body}</div>`;d.className=wide?'wide':'';if(!d.open)d.showModal();}
export function closeModal(){$('#modal').close();}
export function unlockAudio(){syncMusic();}
export function stopQuestionAudio(){questionAudio.pause();questionAudio.currentTime=0;questionKey='';}
const questionAudio=new Audio();let questionKey='';
export function playQuestionAudio(key,src){if(!src||questionKey===key)return;questionAudio.pause();questionKey=key;questionAudio.src=src;questionAudio.volume=Math.min(1,S.volume);questionAudio.play().catch(()=>{toast('مرورگر پخش خودکار را متوقف کرده؛ دکمهٔ پخش صدای سؤال را بزن.');});}
export function coinsToWallet(){if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;const wallet=document.querySelector('.wallet')?.getBoundingClientRect();const x=(wallet?wallet.left+wallet.width/2:innerWidth-35)-innerWidth/2,y=(wallet?wallet.top+wallet.height/2:25)-innerHeight*.45;for(let i=0;i<7;i++){const el=document.createElement('span');el.className='coin-to-wallet';el.style.setProperty('--wallet-x',x+'px');el.style.setProperty('--wallet-y',y+'px');el.style.setProperty('--delay',i*.09+'s');el.innerHTML=icon('coin');document.body.append(el);setTimeout(()=>el.remove(),2400);}}
export function needUser(){if(S.user)return true;document.dispatchEvent(new CustomEvent('login-request'));return false;}
export function go(route){location.hash=route;}
const music=new Audio('/assets/audio/bg_music.mp3');music.loop=true;
const sounds={click:'/assets/audio/click.wav',correct:'/assets/audio/tanswer.ogg',wrong:'/assets/audio/fanswer.ogg',warning:'/assets/audio/warning_time.ogg'};
let audioContext;
export function play(name='click'){
 if(!S.sound||!S.volume||S.settings.soundEnabled===false)return;
 const configured=S.settings.audioFiles?.[name]||sounds[name];if(configured){const a=new Audio(configured);a.volume=Math.min(1,S.volume);a.play().catch(()=>{});return;}
 try{
  audioContext||=new (window.AudioContext||window.webkitAudioContext)();audioContext.resume().catch(()=>{});
  const notes={nav:[440,554],like:[659,880],coin:[784,988,1175],send:[523,784],modal:[330,440],select:[620,740]}[name]||[440];
  notes.forEach((hz,i)=>{const o=audioContext.createOscillator(),g=audioContext.createGain(),at=audioContext.currentTime+i*.055;o.type='sine';o.frequency.value=hz;g.gain.setValueAtTime(0,at);g.gain.linearRampToValueAtTime(S.volume*.09,at+.012);g.gain.exponentialRampToValueAtTime(.001,at+.13);o.connect(g);g.connect(audioContext.destination);o.start(at);o.stop(at+.14);o.onended=()=>{o.disconnect();g.disconnect();};});
 }catch{}
}
export function syncMusic(){const src=S.settings.audioFiles?.music||'/assets/audio/bg_music.mp3';if(!music.src.endsWith(src))music.src=src;music.volume=Math.min(.45,S.volume*.55);if(S.music&&S.settings.musicEnabled!==false&&!document.hidden)music.play().catch(()=>{});else music.pause();localStorage.setItem('gm-music',S.music?'on':'off');localStorage.setItem('gm-sound',S.sound?'on':'off');localStorage.setItem('gm-volume',String(S.volume));}
document.addEventListener('visibilitychange',syncMusic);
document.addEventListener('pointerdown',()=>{if(S.music)syncMusic();},{once:true});
export async function upload(file){if(!file)return '';if(file.size>12*1024*1024)throw new Error('حداکثر حجم فایل ۱۲ مگابایت است.');const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result.split(',')[1]);r.onerror=reject;r.readAsDataURL(file);});const result=await api('/upload','POST',{mime:file.type==='audio/x-wav'?'audio/wav':file.type,data});return result.path;}
export async function confirmAction(title,message,action){modal(title,`<p class="muted">${h(message)}</p><div class="button-row"><button class="btn danger" id="confirm-action">تأیید</button><button class="btn secondary" data-a="close-modal">بازگشت</button></div>`);$('#confirm-action').onclick=async()=>{const b=$('#confirm-action');b.disabled=true;try{await action();closeModal();}catch(e){toast(e.message,true);b.disabled=false;}};}
export function downloadJSON(name,data){const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}

export function mountQuestionAudio(container,key,src){if(!container||!src)return;questionAudio.controls=true;questionAudio.preload='metadata';container.replaceChildren(questionAudio);playQuestionAudio(key,src);}
