/* سرور گی‌میفای: فایل‌های سایت + API + ذخیرهٔ دائمی روی فایل JSON — بدون هیچ وابستگی (Node 16+) */
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = Number(process.env.PORT || 3001);
const HOST = process.env.HOST || "127.0.0.1";
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data-app");
const DIST = path.join(__dirname, "dist");
fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------- ذخیرهٔ دائمی (فایل JSON) ---------- */
const DATA_FILE = path.join(DATA_DIR, "app.json");
let data = { users: [], tokens: {}, messages: [] };
try {
  if (fs.existsSync(DATA_FILE)) data = { users: [], tokens: {}, messages: [], ...JSON.parse(fs.readFileSync(DATA_FILE, "utf8")) };
} catch { /* فایل خراب → از صفر شروع می‌کنیم */ }
let saveTimer = null;
const save = () => {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const tmp = DATA_FILE + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(data));
    fs.renameSync(tmp, DATA_FILE);
  }, 300);
};

const uid = (p) => p + crypto.randomBytes(6).toString("hex");
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".json": "application/json", ".ico": "image/x-icon", ".woff2": "font/woff2" };

const parseCookies = (req) => Object.fromEntries((req.headers.cookie || "").split(";").map((c) => c.trim().split("=")).filter((x) => x[0]).map(([k, ...v]) => [k, v.join("=")]));
const json = (res, code, bodyObj) => { res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }); res.end(JSON.stringify(bodyObj)); };
const readBody = (req) => new Promise((resolve) => { let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => { try { resolve(JSON.parse(b || "{}")); } catch { resolve({}); } }); });

const userById = (id) => data.users.find((u) => u.id === id) || null;
const authUser = (req) => {
  const t = parseCookies(req).gtok;
  if (!t || !data.tokens[t]) return null;
  const u = userById(data.tokens[t]);
  if (u) { u.last_seen = Date.now(); save(); }
  return u;
};
const setTok = (res, userId) => {
  const t = uid("t");
  data.tokens[t] = userId;
  save();
  const secure = BASE_URL.startsWith("https") ? "; Secure" : "";
  res.setHeader("Set-Cookie", `gtok=${t}; Path=/; HttpOnly; SameSite=Lax${secure}`);
};
const pub = (u) => ({ id: u.id, name: u.name, avatar: u.avatar, interests: u.interests || [], provider: u.provider, email: u.email, xp: u.xp, coins: u.coins, cups: u.cups, streak: u.streak, wins: u.wins, played: u.played, rating: u.rating, bio: u.bio, last_seen: u.last_seen });
const originOk = (req) => { const o = req.headers.origin; if (!o) return true; return o === BASE_URL; };

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, BASE_URL);
  const p = url.pathname;

  if (p === "/health") return json(res, 200, { ok: true });

  /* ---------- ورود با گوگل ---------- */
  if (p === "/auth/google") {
    if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) { res.writeHead(302, { Location: "/#home" }); return res.end(); }
    const params = new URLSearchParams({ client_id: process.env.GOOGLE_CLIENT_ID, redirect_uri: BASE_URL + "/auth/google/callback", response_type: "code", scope: "openid email profile", state: uid("s"), prompt: "select_account" });
    res.writeHead(302, { Location: "https://accounts.google.com/o/oauth2/v2/auth?" + params });
    return res.end();
  }
  if (p === "/auth/google/callback") {
    try {
      const tokenRes = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ code: url.searchParams.get("code") || "", client_id: process.env.GOOGLE_CLIENT_ID, client_secret: process.env.GOOGLE_CLIENT_SECRET, redirect_uri: BASE_URL + "/auth/google/callback", grant_type: "authorization_code" }) });
      const token = await tokenRes.json();
      if (token.access_token) {
        const profileRes = await fetch("https://openidconnect.googleapis.com/v1/userinfo", { headers: { Authorization: "Bearer " + token.access_token } });
        const prof = await profileRes.json();
        if (prof.sub) {
          let u = data.users.find((x) => x.google_sub === prof.sub);
          if (!u) {
            u = { id: uid("u"), name: String(prof.name || "بازیکن").slice(0, 40), avatar: 1, interests: [], provider: "google", google_sub: prof.sub, email: prof.email || "", phone: "", xp: 0, coins: 50, cups: 0, streak: 0, wins: 0, played: 0, rating: 1000, bio: "", last_seen: Date.now(), created_at: Date.now() };
            data.users.push(u);
          }
          setTok(res, u.id);
        }
      }
    } catch { /* خطای گوگل → برگشت به خانه */ }
    res.writeHead(302, { Location: "/#home" });
    return res.end();
  }

  /* ---------- ثبت میهمان ---------- */
  if (p === "/api/auth/guest" && req.method === "POST") {
    if (!originOk(req)) return json(res, 403, { error: "مبدأ درخواست مجاز نیست." });
    const b = await readBody(req);
    const u = { id: uid("u"), name: String(b.name || "میهمان").slice(0, 40), avatar: b.avatar ?? 1, interests: Array.isArray(b.interests) ? b.interests : [], provider: b.provider || "guest", google_sub: "", email: b.email || "", phone: b.phone || "", xp: 0, coins: 50, cups: 0, streak: 0, wins: 0, played: 0, rating: 1000, bio: "", last_seen: Date.now(), created_at: Date.now() };
    data.users.push(u);
    save();
    setTok(res, u.id);
    return json(res, 200, pub(u));
  }

  /* ---------- پروفایل من ---------- */
  if (p === "/api/me" && req.method === "GET") {
    const u = authUser(req);
    return u ? json(res, 200, pub(u)) : json(res, 401, { error: "not-authed" });
  }
  if (p === "/api/me" && req.method === "POST") {
    if (!originOk(req)) return json(res, 403, { error: "مبدأ درخواست مجاز نیست." });
    const u = authUser(req);
    if (!u) return json(res, 401, { error: "not-authed" });
    const b = await readBody(req);
    for (const k of ["xp", "coins", "cups", "streak", "wins", "played", "rating"]) if (typeof b[k] === "number") u[k] = Math.max(0, Math.round(b[k]));
    if (typeof b.name === "string" && b.name.trim()) u.name = b.name.trim().slice(0, 40);
    if (b.avatar !== undefined) u.avatar = b.avatar;
    if (Array.isArray(b.interests)) u.interests = b.interests;
    if (typeof b.bio === "string") u.bio = b.bio.slice(0, 200);
    save();
    return json(res, 200, pub(u));
  }

  /* ---------- بازیکنان واقعی ---------- */
  if (p === "/api/players") {
    authUser(req);
    const rows = [...data.users].sort((a, b) => b.xp - a.xp).slice(0, 200);
    return json(res, 200, rows.map(pub));
  }

  /* ---------- گفت‌وگوی واقعی ---------- */
  if (p === "/api/messages" && req.method === "GET") {
    const u = authUser(req);
    if (!u) return json(res, 401, { error: "not-authed" });
    const withId = url.searchParams.get("with") || "";
    const rows = data.messages
      .filter((m) => (m.from_id === u.id && m.to_id === withId) || (m.from_id === withId && m.to_id === u.id))
      .sort((a, b) => a.at - b.at)
      .slice(-200);
    for (const m of rows) if (m.from_id === withId && m.to_id === u.id) m.read = 1;
    save();
    return json(res, 200, rows);
  }
  if (p === "/api/messages" && req.method === "POST") {
    if (!originOk(req)) return json(res, 403, { error: "مبدأ درخواست مجاز نیست." });
    const u = authUser(req);
    if (!u) return json(res, 401, { error: "not-authed" });
    const b = await readBody(req);
    const to = String(b.to || "");
    const text = String(b.text || "").slice(0, 500);
    if (!to || !text || !userById(to)) return json(res, 400, { error: "bad-request" });
    const msg = { id: uid("m"), from_id: u.id, to_id: to, text, at: Date.now(), read: 0 };
    data.messages.push(msg);
    save();
    return json(res, 200, { id: msg.id, at: msg.at });
  }

  /* ---------- فایل‌های استاتیک ---------- */
  let file = path.normalize(path.join(DIST, p === "/" ? "index.html" : p));
  if (!file.startsWith(DIST)) file = path.join(DIST, "index.html");
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(DIST, "index.html");
  res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream", "Cache-Control": file.endsWith("index.html") ? "no-store" : "public, max-age=3600" });
  fs.createReadStream(file).pipe(res);
});

server.listen(PORT, HOST, () => console.log(`Gamify app server ready on ${BASE_URL} (port ${PORT})`));
