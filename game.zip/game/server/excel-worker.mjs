import {parentPort,workerData} from 'node:worker_threads';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
try{
 const bytes=Buffer.from(workerData);
 // Check the ZIP central directory before allowing decompression.
 let end=-1;for(let p=bytes.length-22;p>=Math.max(0,bytes.length-65557);p--)if(bytes.readUInt32LE(p)===0x06054b50){end=p;break;}
 if(end<0)throw Error('فایل XLSX معتبر نیست؛ فایل XLS قدیمی را با قالب XLSX ذخیره کنید.');
 const count=bytes.readUInt16LE(end+10),offset=bytes.readUInt32LE(end+16);let p=offset,total=0;
 if(count>250||bytes.readUInt16LE(end+4)!==0||offset>=end)throw Error('ساختار فایل پشتیبانی نمی‌شود.');
 for(let i=0;i<count;i++){
  if(p+46>end||bytes.readUInt32LE(p)!==0x02014b50)throw Error('ساختار فایل خراب است.');
  const size=bytes.readUInt32LE(p+24),compressed=bytes.readUInt32LE(p+20),flags=bytes.readUInt16LE(p+8),nameLength=bytes.readUInt16LE(p+28);
  const name=bytes.toString('utf8',p+46,p+46+nameLength);
  total+=size;if(flags&1||total>20*1024*1024||size>12*1024*1024||size>Math.max(compressed,1)*250)throw Error('فایل رمزدار یا بیش از حد فشرده است.');
  if(/vbaProject|externalLinks|embeddings/i.test(name))throw Error('ماکرو، پیوند خارجی یا فایل توکار پشتیبانی نمی‌شود.');
  p+=46+nameLength+bytes.readUInt16LE(p+30)+bytes.readUInt16LE(p+32);
 }
 const ExcelJS=require('./vendor/exceljs.cjs'),book=new ExcelJS.Workbook();
 // Import cell values only. Notes and drawings are not question media. ExcelJS 4.4
 // cannot reconcile openpyxl's comments paths; omit those relations deliberately.
 const reconcile=book.xlsx.reconcile.bind(book.xlsx);
 book.xlsx.reconcile=(model,options)=>{
  for(const key of Object.keys(model.worksheetRels))model.worksheetRels[key]=model.worksheetRels[key].filter(r=>!/(comments|vmlDrawing|drawing)$/.test(r.Type)).map(r=>({...r,Target:r.Target?.replace(/^\/xl\//,'../')}));
  return reconcile(model,options);
 };
 await book.xlsx.load(bytes,{ignoreNodes:['drawing','legacyDrawing']});
 const sheet=book.getWorksheet('سؤالات');if(!sheet)throw Error('برگه‌ای با نام «سؤالات» در فایل وجود ندارد.');
 if(sheet.rowCount>1000||sheet.columnCount>30)throw Error('برگه بیش از حد بزرگ است؛ حداکثر ۵۰۰ سؤال وارد کنید.');
 const rows=[];sheet.eachRow({includeEmpty:false},(r,row)=>{
  const values=[];for(let c=1;c<=sheet.columnCount;c++){
   const v=r.getCell(c).value;
   if(v&&typeof v==='object'){
    if('formula'in v||'sharedFormula'in v||'error'in v)throw Error(`ردیف ${row}: فرمول و خطای اکسل مجاز نیست؛ مقدار را به صورت متن وارد کنید.`);
    if(v.richText)values.push(v.richText.map(x=>x.text).join(''));
    else if(v.hyperlink)values.push(v.text||v.hyperlink);
    else throw Error(`ردیف ${row}: نوع سلول پشتیبانی نمی‌شود.`);
   }else values.push(v??'');
  }rows.push({row,values});
 });parentPort.postMessage({rows});
}catch(e){parentPort.postMessage({error:e.message});}
