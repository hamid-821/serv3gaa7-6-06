import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {createApp} from '../server/index.mjs';
import {settleCompetitions,rankedPlayers} from '../server/features.mjs';
test('Rewards, usable cosmetics, fixed-question open challenge and one-time podium awards',async()=>{
 mkdirSync('audit/test-runs',{recursive:true});const app=createApp({dataDir:mkdtempSync(resolve('audit/test-runs/features-')),baseUrl:'http://localhost:3000',adminKey:'features-test-owner-123456789012345',testing:true});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;
 function client(){let cookie='',csrf='';return {id:'',async call(p,m='GET',b){const r=await fetch(base+'/api'+p,{method:m,headers:{Origin:'http://localhost:3000','Content-Type':'application/json',Cookie:cookie,'X-CSRF-Token':csrf},...(b?{body:JSON.stringify(b)}:{})});if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie').split(';')[0];const data=await r.json();if(data.csrf){csrf=data.csrf;this.id=data.user.id;}return {status:r.status,data};}};}
 const a=client(),b=client();try{
  for(const [i,c]of [a,b].entries())await c.call('/auth/guest','POST',{name:'بازیکن رویداد '+i,avatar:i+1,interests:['electric']});
  const gift=await a.call('/features/rewards/claim','POST',{kind:'daily'});assert.equal(gift.status,200,JSON.stringify(gift.data));assert.ok([10,15,20,25,30,40].includes(gift.data.coins));assert.equal((await a.call('/features/rewards/claim','POST',{kind:'daily'})).status,400);assert.equal((await a.call('/features/rewards/claim','POST',{kind:'chest'})).status,400);
  const before=app.db.prepare('SELECT coins FROM users WHERE id=?').get(a.id).coins;assert.equal((await a.call('/features/store/buy','POST',{item:'frame-violet'})).status,200);assert.equal(app.db.prepare('SELECT coins FROM users WHERE id=?').get(a.id).coins,before-80);assert.equal((await a.call('/features/store/buy','POST',{item:'frame-violet'})).status,400);assert.equal((await a.call('/features/store/equip','POST',{item:'frame-violet'})).status,200);assert.equal((await a.call('/bootstrap')).data.user.cosmetics.frame,'frame-violet');assert.equal((await a.call('/features/store/equip','POST',{item:'frame-gold'})).status,400);
  const created=await a.call('/features/competitions','POST',{category:'electric',title:'چالش آزمایشی برق',hours:1,description:'آزمون برابری سؤال‌ها'});assert.equal(created.status,200,JSON.stringify(created.data));const event=created.data.id;
  const first=app.game.create(a.id,'electric','tournament',null,event),snapshot=JSON.parse(app.game.get(first.id).questions);
  // Later bank edits must not change the event's shared set of questions.
  app.db.prepare("UPDATE questions SET title=title||' ویرایش بانک' WHERE category='electric'").run();
  const second=app.game.create(b.id,'electric','tournament',null,event);assert.deepEqual(JSON.parse(app.game.get(second.id).questions),snapshot);
  for(const [id,uid,correct]of [[first.id,a.id,true],[second.id,b.id,false]])for(let round=0;round<7;round++){const q=JSON.parse(app.game.get(id).questions)[round];app.game.answer(id,uid,round,correct?q.correct:(q.correct+1)%4);app.db.prepare('UPDATE matches SET round_at=? WHERE id=?').run(Date.now()-5000,id);app.game.advance(app.game.get(id));}
  assert.throws(()=>app.game.create(a.id,'electric','tournament',null,event),/فقط یک بار/);
  const ranks=await b.call('/features/competitions/'+event+'/leaderboard');assert.equal(ranks.data.rows[0].id,a.id);assert.equal(ranks.data.rows[0].correct,7);
  app.db.prepare('UPDATE tournaments SET ends_at=? WHERE id=?').run(Date.now()-1000,event);const old=app.db.prepare('SELECT cups,coins FROM users WHERE id=?').get(a.id);settleCompetitions(app.db);const won=app.db.prepare('SELECT cups,coins FROM users WHERE id=?').get(a.id);assert.equal(won.cups,old.cups+1);assert.equal(won.coins,old.coins+100);settleCompetitions(app.db);assert.deepEqual(app.db.prepare('SELECT cups,coins FROM users WHERE id=?').get(a.id),won);
  const badges=await a.call('/features/achievements/'+a.id);assert.ok(badges.data.badges.find(x=>x.id==='first-game').unlocked);assert.equal(badges.data.awards[0].rank,1);
  assert.equal(rankedPlayers(app.db,{period:'week',metric:'cups'})[0].points,1);
  assert.equal(rankedPlayers(app.db,{period:'month',metric:'xp',userId:a.id})[0].points,70);
  assert.equal(rankedPlayers(app.db,{period:'all',metric:'xp',userId:a.id})[0].rank,1);
 }finally{await app.close();}
});
