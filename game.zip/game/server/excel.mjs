import {Worker} from 'node:worker_threads';
export const HEADERS=['دسته‌بندی','متن سؤال','گزینه ۱','گزینه ۲','گزینه ۳','گزینه ۴','گزینه صحیح','توضیح پاسخ','زمان (ثانیه)','نوع سؤال','مسیر رسانه','مسیر صدا','منبع'];
export const normalize=v=>String(v??'').normalize('NFKC').replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[\u200c\u200e\u200f]/g,' ').replace(/\s+/g,' ').trim();
export const number=v=>Number(normalize(v).replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))));
export function questionKey(q){return normalize(q.category)+'|'+normalize(q.title);}
export function mapRows(rows,categories){
 if(!rows.length)throw Error('برگهٔ «سؤالات» خالی است.');
 const headers=rows[0].values.map(normalize),indices=HEADERS.map(h=>headers.indexOf(normalize(h)));
 if(indices.slice(0,8).some(i=>i<0))throw Error('ستون‌های الزامی با قالب نمونه مطابقت ندارند. از فایل نمونه استفاده کنید.');
 if(new Set(headers.filter(Boolean)).size!==headers.filter(Boolean).length)throw Error('عنوان ستون تکراری است.');
 const output=[];
 for(const row of rows.slice(1)){
  if(row.values.every(v=>v===''||v===null||v===undefined))continue;
  const read=i=>indices[i]<0?'':row.values[indices[i]]??'';
  try{
   const name=normalize(read(0)),matches=categories.filter(c=>c.id===name||normalize(c.name)===name);
   if(matches.length!==1)throw Error('دسته‌بندی پیدا نشد یا مبهم است؛ نام دقیق یا شناسهٔ برگهٔ دسته‌بندی‌ها را وارد کنید.');
   const correct=number(read(6));if(!Number.isInteger(correct)||correct<1||correct>4)throw Error('گزینه صحیح باید عددی از ۱ تا ۴ باشد.');
   const seconds=read(8)===''?25:number(read(8));if(!Number.isInteger(seconds)||seconds<10||seconds>120)throw Error('زمان باید عدد صحیح از ۱۰ تا ۱۲۰ ثانیه باشد.');
   const kind={'':'text','متنی':'text','تصویری':'image','ویدیویی':'video',text:'text',image:'image',video:'video'}[normalize(read(9))];
   if(!kind)throw Error('نوع سؤال باید متنی، تصویری یا ویدیویی باشد.');
   output.push({row:row.row,question:{category:matches[0].id,title:String(read(1)).trim(),options:[2,3,4,5].map(i=>String(read(i)).trim()),correct:correct-1,explanation:String(read(7)).trim(),seconds,kind,media:String(read(10)).trim(),audio:String(read(11)).trim(),source:String(read(12)).trim()}});
  }catch(e){output.push({row:row.row,error:e.message});}
 }
 if(!output.length||output.length>500)throw Error('هر فایل باید بین ۱ تا ۵۰۰ سؤال داشته باشد.');
 return output;
}
export function parseWorkbook(bytes){
 if(bytes.length>5*1024*1024)throw Error('فایل اکسل حداکثر ۵ مگابایت باشد.');
 return new Promise((resolve,reject)=>{
  const worker=new Worker(new URL('./excel-worker.mjs',import.meta.url),{workerData:bytes,resourceLimits:{maxOldGenerationSizeMb:160,maxYoungGenerationSizeMb:32}});
  let done=false;const finish=(error,value)=>{if(done)return;done=true;clearTimeout(timer);worker.terminate();error?reject(error):resolve(value);};
  const timer=setTimeout(()=>finish(Error('خواندن فایل طولانی شد؛ فایل را کوچک‌تر کنید.')),12000);
  worker.once('message',m=>finish(m.error?Error(m.error):null,m.rows));worker.once('error',()=>finish(Error('فایل قابل پردازش نیست.')));worker.once('exit',()=>{if(!done)finish(Error('پردازش فایل متوقف شد.'));});
 });
}
