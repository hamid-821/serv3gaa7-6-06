import {isIP} from 'node:net';
import {dailyRoute} from './daily.mjs';
import {storiesRoute} from './stories.mjs';
import {leaguesRoute} from './leagues.mjs';
import http from 'node:http';
import {readFileSync,writeFileSync,existsSync,mkdirSync,statSync,createReadStream} from 'node:fs';
import {resolve,dirname,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes,randomUUID,createHash,timingSafeEqual} from 'node:crypto';
import {featuresRoute,settleCompetitions,rankedPlayers} from './features.mjs';
import {platformRoute,platformTick,safeLink} from './platform.mjs';
import {socialRoute} from './social.mjs';
import {openDB} from './db.mjs';
import {Game,GameError,fail} from './game.mjs';
import {parseWorkbook,mapRows,questionKey} from './excel.mjs';
const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..'),PUBLIC=resolve(ROOT,'public');
export function createApp(options={}){
 const data=resolve(options.dataDir||process.env.DATA_DIR||resolve(ROOT,'data'));mkdirSync(resolve(data,'uploads'),{recursive:true});
 const db=openDB(data),streams=new Map(),presence=new Map(),limits=new Map(),oauthStates=new Map(),excelPreviews=new Map();
 const base=options.baseUrl||process.env.BASE_URL||'http://localhost:3000',secure=base.startsWith('https:'),baseOrigin=new URL(base).origin;
 let adminKey=options.adminKey||process.env.ADMIN_KEY;
 if(!adminKey){const keyFile=resolve(data,'admin-key.txt');if(!existsSync(keyFile))writeFileSync(keyFile,randomBytes(24).toString('base64url'),{mode:0o600});adminKey=readFileSync(keyFile,'utf8').trim();}
 if(adminKey.length<24)throw new Error('ADMIN_KEY must contain at least 24 characters.');
 const uid=()=>randomUUID(),hash=s=>createHash('sha256').update(s).digest('hex'),now=()=>Date.now();
 const setting=k=>JSON.parse(db.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value??'null');
 const settings=()=>Object.fromEntries(db.prepare('SELECT * FROM settings').all().map(x=>[x.key,JSON.parse(x.value)]));
 const notify=(id,type,payload)=>{for(const res of streams.get(id)||[])res.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`);};
 const game=new Game(db,notify);
 function transaction(fn){db.exec('BEGIN IMMEDIATE');try{const v=fn();db.exec('COMMIT');return v;}catch(e){db.exec('ROLLBACK');throw e;}}
 function json(res,value,status=200){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
 function cookie(res,name,value,maxAge=2592000){res.setHeader('Set-Cookie',`${name}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure?'; Secure':''}`);}
 function cookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').map(v=>v.trim().split('=')).filter(v=>v.length===2));}
 function session(req){const token=cookies(req).gm_session;if(!token)return null;return db.prepare('SELECT s.csrf,s.token,u.* FROM sessions s JOIN users u ON s.user_id=u.id WHERE s.token=? AND s.expires>? AND u.banned=0').get(hash(token),now());}
 function newSession(res,id){const token=randomBytes(32).toString('base64url'),csrf=randomBytes(24).toString('base64url');db.prepare('INSERT INTO sessions VALUES (?,?,?,?)').run(hash(token),id,csrf,now()+2592000000);cookie(res,'gm_session',token);return csrf;}
 function pub(u,me=false){if(!u)return null;const {id,name,avatar,bio,role,xp,coins,cups,streak,interests,private:priv,is_demo}=u;return {id,name,avatar,bio,role,xp,cups,streak,interests:JSON.parse(interests),private:!!priv,isDemo:!!is_demo,level:Math.floor(xp/250)+1,cosmetics:db.prepare('SELECT frame,title FROM cosmetics WHERE user_id=?').get(id)||{},...(me?{coins,emojiUnlocked:!!db.prepare("SELECT 1 FROM inventory WHERE user_id=? AND item='emoji-stars'").get(id),googleConnected:!!u.google_sub}:{} )};}
 function audit(actor,action,target=''){db.prepare('INSERT INTO audit_log(actor,action,target,created_at) VALUES (?,?,?,?)').run(actor,action,target,now());}
 function notice(id,title,body='',link=''){const nid=uid();db.prepare('INSERT INTO notifications VALUES (?,?,?,?,?,0)').run(nid,id,title,body,now());if(link)db.prepare('INSERT INTO notification_links VALUES (?,?)').run(nid,link);notify(id,'notification',{id:nid,title,body,link});}
 function limited(key,max=80,ms=60000){let v=limits.get(key);if(!v||now()-v.at>ms){v={at:now(),n:0};limits.set(key,v);}fail(++v.n>max,'درخواست‌های شما زیاد است. کمی صبر کنید.',429);}
 async function body(req){fail(!req.headers['content-type']?.startsWith('application/json'),'قالب درخواست نامعتبر است.',415);let size=0,chunks=[];for await(const c of req){size+=c.length;fail(size>18*1024*1024,'حجم فایل بیش از حد مجاز است.',413);chunks.push(c);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}');}catch{throw new GameError('درخواست قابل خواندن نیست.');}}
 function text(v,min=1,max=2000){fail(typeof v!=='string'||v.trim().length<min||v.length>max,`متن باید بین ${min} و ${max} نویسه باشد.`);return v.trim();}
 function validCategory(id){fail(!db.prepare('SELECT 1 FROM categories WHERE id=? AND active=1').get(id),'موضوع نامعتبر است.');return id;}
 function media(path,owner,kinds=['image/']){if(!path)return '';fail(typeof path!=='string','فایل نامعتبر است.');const f=db.prepare('SELECT * FROM uploads WHERE path=? AND owner=?').get(path,owner);fail(!f||!kinds.some(k=>f.mime.startsWith(k)),'این فایل متعلق به شما نیست یا نوع مناسبی ندارد.');return path;}
 function canSeeUser(viewer,target){return !target.private||viewer?.id===target.id||viewer?.role==='admin'||!!db.prepare("SELECT 1 FROM follows WHERE user_id=? AND target_id=? AND status='approved'").get(viewer?.id||'',target.id);}
 function postAccess(id,u){const p=db.prepare('SELECT * FROM posts WHERE id=?').get(id);fail(!p,'مطلب پیدا نشد.',404);const author=db.prepare('SELECT * FROM users WHERE id=?').get(p.user_id);fail(u?.role!=='admin'&&((p.status!=='approved'&&p.user_id!==u?.id)||!canSeeUser(u,author)||game.blocked(u?.id||'',author.id)),'این مطلب در دسترس نیست.',403);return p;}
 function validateQuestion(b,user){const category=validCategory(b.category),title=text(b.title,5,1000);fail(!Array.isArray(b.options)||b.options.length!==4,'چهار گزینه لازم است.');const opts=b.options.map(o=>text(o,1,300));fail(new Set(opts).size!==4,'گزینه‌ها باید متفاوت باشند.');fail(!Number.isInteger(b.correct)||b.correct<0||b.correct>3,'پاسخ درست را انتخاب کنید.');const kind=['text','image','video'].includes(b.kind)?b.kind:'text';
  const file=media(b.media,user.id,kind==='video'?['video/']:['image/']);fail(kind!=='text'&&!file,'فایل این سؤال را بارگذاری کنید.');
  const source=b.source?text(b.source,1,600):'';fail(source&&!/^https:\/\//.test(source)&&!db.prepare('SELECT 1 FROM resource_library WHERE path=?').get(source),'نشانی منبع باید با https آغاز شود.');
  return {id:b.id||uid(),category,title,options:JSON.stringify(opts),correct:b.correct,explanation:text(b.explanation,5,2000),source,seconds:Math.min(120,Math.max(10,Number(b.seconds)||25)),kind,media:file,audio:media(b.audio,user.id,['audio/'])};
 }
 function uploadFile(b,u){const allowed={'image/jpeg':{ext:'.jpg',check:x=>x[0]===255&&x[1]===216&&x[2]===255},'image/png':{ext:'.png',check:x=>x.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))},'image/webp':{ext:'.webp',check:x=>x.toString('ascii',0,4)==='RIFF'&&x.toString('ascii',8,12)==='WEBP'},'image/gif':{ext:'.gif',check:x=>['GIF87a','GIF89a'].includes(x.toString('ascii',0,6))},'video/mp4':{ext:'.mp4',check:x=>x.toString('ascii',4,8)==='ftyp'},'audio/mpeg':{ext:'.mp3',check:x=>x.toString('ascii',0,3)==='ID3'||(x[0]===255&&(x[1]&224)===224)},'audio/ogg':{ext:'.ogg',check:x=>x.toString('ascii',0,4)==='OggS'},'audio/wav':{ext:'.wav',check:x=>x.toString('ascii',0,4)==='RIFF'&&x.toString('ascii',8,12)==='WAVE'}};
  const type=allowed[b.mime];fail(!type,'فرمت مجاز: JPG، PNG، WEBP، GIF، MP4، MP3، OGG، WAV.');fail(typeof b.data!=='string'||!/^[A-Za-z0-9+/]*={0,2}$/.test(b.data),'فایل نامعتبر است.');const bytes=Buffer.from(b.data,'base64');fail(bytes.length<12||bytes.length>(b.mime.startsWith('image/')?5:12)*1024*1024,'تصویر حداکثر ۵ و صدا یا ویدئو حداکثر ۱۲ مگابایت باشد.');fail(!type.check(bytes),'محتوای فایل با فرمت اعلام‌شده مطابقت ندارد.');
  const quota=db.prepare('SELECT COALESCE(SUM(size),0) n FROM uploads WHERE owner=? AND created_at>?').get(u.id,now()-86400000).n;fail(u.role!=='admin'&&quota+bytes.length>60*1024*1024,'سهمیهٔ بارگذاری امروز تکمیل شده است.');
  const id=uid(),path='/uploads/'+id+type.ext;writeFileSync(resolve(data,'uploads',id+type.ext),bytes);db.prepare('INSERT INTO uploads VALUES (?,?,?,?,?,?)').run(id,u.id,path,b.mime,bytes.length,now());return {path,mime:b.mime};
 }
 const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(self), microphone=(self), geolocation=()');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; font-src 'self'; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self' https://accounts.google.com");
  if(secure)res.setHeader('Strict-Transport-Security','max-age=31536000');
  try{
   const url=new URL(req.url,base),path=url.pathname,method=req.method,u=session(req),ip=(process.env.TRUST_PROXY==='1'&&isIP(String(req.headers['x-forwarded-for']||'').split(',')[0].trim())?String(req.headers['x-forwarded-for']).split(',')[0].trim():req.socket.remoteAddress)||'local';
   if(u)presence.set(u.id,now());
   if(path==='/health')return json(res,{ok:true,name:'Gamify 2'});
   if(path.startsWith('/auth/google')){
    fail(!process.env.GOOGLE_CLIENT_ID||!process.env.GOOGLE_CLIENT_SECRET,'ورود گوگل هنوز توسط مدیر پیکربندی نشده است. از ورود مهمان استفاده کنید.',503);
    limited('oauth:'+ip,20);
    if(path==='/auth/google'){
     const state=randomBytes(24).toString('base64url'),bind=randomBytes(24).toString('base64url');oauthStates.set(state,{bind:hash(bind),at:now(),user:u?.id});cookie(res,'gm_oauth',bind,600);
     const params=new URLSearchParams({client_id:process.env.GOOGLE_CLIENT_ID,redirect_uri:base+'/auth/google/callback',response_type:'code',scope:'openid email profile',state,prompt:'select_account'});
     res.writeHead(302,{Location:'https://accounts.google.com/o/oauth2/v2/auth?'+params});return res.end();
    }
    const state=url.searchParams.get('state'),saved=oauthStates.get(state);oauthStates.delete(state);fail(!saved||saved.at<now()-600000||saved.bind!==hash(cookies(req).gm_oauth||''),'درخواست ورود منقضی یا نامعتبر است. دوباره تلاش کنید.');
    fail(url.searchParams.has('error'),'ورود با گوگل لغو شد.');
    const tokenRes=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code:url.searchParams.get('code')||'',client_id:process.env.GOOGLE_CLIENT_ID,client_secret:process.env.GOOGLE_CLIENT_SECRET,redirect_uri:base+'/auth/google/callback',grant_type:'authorization_code'}),signal:AbortSignal.timeout(10000)});const token=await tokenRes.json();fail(!tokenRes.ok||!token.access_token,'ارتباط با گوگل موفق نبود.',502);
    const profileRes=await fetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:'Bearer '+token.access_token},signal:AbortSignal.timeout(10000)});const profile=await profileRes.json();fail(!profileRes.ok||!profile.sub||profile.email_verified!==true,'هویت حساب گوگل تأیید نشد.',401);
    let user=db.prepare('SELECT * FROM users WHERE google_sub=?').get(profile.sub);
    if(!user){const guest=saved.user?db.prepare('SELECT * FROM users WHERE id=? AND google_sub IS NULL AND banned=0').get(saved.user):null;const id=guest?.id||uid();
     if(guest)db.prepare('UPDATE users SET google_sub=?,email=? WHERE id=?').run(profile.sub,profile.email,id);
     else db.prepare('INSERT INTO users(id,name,avatar,google_sub,email,created_at) VALUES (?,?,?,?,?,?)').run(id,String(profile.name||'بازیکن').slice(0,40),'/assets/avatars/1.svg',profile.sub,profile.email,now());
     user=db.prepare('SELECT * FROM users WHERE id=?').get(id);
    }fail(user.banned,'حساب شما غیرفعال است.',403);
    if((process.env.ADMIN_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).includes(profile.email.toLowerCase()))db.prepare("UPDATE users SET role='admin' WHERE id=?").run(user.id);
    newSession(res,user.id);res.writeHead(302,{Location:'/#home'});return res.end();
   }
   if(path.startsWith('/api/')){
    const mutate=!['GET','HEAD'].includes(method);
    if(mutate){fail(req.headers.origin!==baseOrigin,'مبدأ درخواست مجاز نیست.',403);limited('write:'+(u?.id||ip),options.testing?10000:150);if(!['/api/auth/guest','/api/platform/auth/email'].includes(path)){fail(!u,'ابتدا وارد شوید.',401);fail(req.headers['x-csrf-token']!==u.csrf,'نشست تغییر کرده است؛ صفحه را تازه کنید.',403);}}
    const b=mutate?await body(req):null;
    if(await dailyRoute({path,method,b,u,db,res,json,fail,transaction}))return;
    if(await storiesRoute({path,method,b,u,db,game,res,json,fail,text,media,setting,notice,postAccess}))return;
    if(await leaguesRoute({path,method,url,b,u,db,game,json,res,fail,text,transaction,audit}))return;
    if(await platformRoute({path,method,url,b,u,db,game,res,json,fail,text,media,audit,transaction,notice,notify,presence,data,newSession,pub,limited,ip}))return;
    if(await featuresRoute({path,method,url,b,u,db,game,json,res,fail,text,transaction,setting,audit,notice}))return;
    if(await socialRoute({path,method,url,b,u,db,game,json,res,fail,text,media,postAccess,setting,audit,transaction}))return;
    if(path==='/api/bootstrap'&&method==='GET'){
     const cats=db.prepare("SELECT c.*,(SELECT COUNT(*) FROM questions q WHERE q.category=c.id AND status='approved') questionCount FROM categories c WHERE active=1").all();
     return json(res,{user:pub(u,true),csrf:u?.csrf,settings:settings(),googleEnabled:!!(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET),categories:cats,online:[...presence].filter(([id,t])=>now()-t<45000&&id!==u?.id).length,activeMatch:u?game.active(u.id)?.id:null,stats:u?db.prepare('SELECT * FROM category_stats WHERE user_id=?').all(u.id):[],reviewCount:u?db.prepare('SELECT COUNT(*) n FROM reviews WHERE user_id=? AND due_at<=?').get(u.id,now()).n:0,unread:u?db.prepare('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND seen=0').get(u.id).n:0,unreadMessages:u?db.prepare('SELECT COUNT(*) n FROM messages WHERE recipient=? AND seen=0').get(u.id).n:0});
    }
    if(path==='/api/auth/guest'&&method==='POST'){
     limited('guest:'+ip,options.testing?100:12,3600000);const name=text(b.name,2,40);fail(!Number.isInteger(b.avatar)||b.avatar<1||b.avatar>10,'یک آواتار انتخاب کنید.');fail(!Array.isArray(b.interests)||b.interests.length<1||b.interests.length>3,'بین یک تا سه علاقه انتخاب کنید.');const interests=[...new Set(b.interests)].map(validCategory),id=uid(),age=b.age==null||b.age===''?null:Number(b.age);fail(age!==null&&(!Number.isInteger(age)||age<4||age>110),'سن معتبر وارد کنید.');
     db.prepare('INSERT INTO users(id,name,avatar,interests,created_at) VALUES (?,?,?,?,?)').run(id,name,`/assets/avatars/${b.avatar}.svg`,JSON.stringify(interests),now());db.prepare('INSERT INTO player_details(user_id,age) VALUES (?,?)').run(id,age);const csrf=newSession(res,id);notice(id,'به گیمیفای ۲ خوش آمدی!','اولین تمرینت را شروع کن؛ پاداش روزانه پس از پایان مسابقه دریافت می‌شود.');return json(res,{user:pub(db.prepare('SELECT * FROM users WHERE id=?').get(id),true),csrf},201);
    }
    if(path==='/api/auth/logout'&&method==='POST'){db.prepare('DELETE FROM sessions WHERE token=?').run(u.token);cookie(res,'gm_session','',0);game.queue.delete(u.id);return json(res,{ok:true});}
    if(path==='/api/events'&&method==='GET'){
     fail(!u,'ابتدا وارد شوید.',401);if(!streams.has(u.id))streams.set(u.id,new Set());fail(streams.get(u.id).size>=5,'تعداد پنجره‌های باز زیاد است.',429);res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});streams.get(u.id).add(res);res.write('event: ready\ndata: {}\n\n');const keep=setInterval(()=>{if(!session(req)){res.end();return;}presence.set(u.id,now());res.write(': heartbeat\n\n');},15000);req.on('close',()=>{clearInterval(keep);streams.get(u.id)?.delete(res);});return;
    }
    if(path==='/api/leaderboard'&&method==='GET')return json(res,rankedPlayers(db,{category:url.searchParams.get('category')||'',period:url.searchParams.get('period')||'all',metric:url.searchParams.get('metric')||'xp',country:url.searchParams.get('country')||'',city:url.searchParams.get('city')||''}).map(x=>({...x,cups:x.private&&u?.id!==x.id?null:x.cups})));
    if(path==='/api/feed'&&method==='GET'){
     fail(!setting('feedEnabled'),'فضای تجربه فعلاً غیرفعال است.',403);const category=url.searchParams.get('category')||'',q=(url.searchParams.get('q')||'').slice(0,100),saved=url.searchParams.get('saved')==='1',viewer=u?.id||'';
     const rows=db.prepare(`SELECT p.*,u.name,u.avatar,u.private,u.is_demo FROM posts p JOIN users u ON p.user_id=u.id WHERE (p.status='approved' OR p.user_id=?) AND u.banned=0 AND (?='' OR p.category=?) AND p.body LIKE ? AND (u.private=0 OR u.id=? OR EXISTS(SELECT 1 FROM follows f WHERE f.user_id=? AND f.target_id=u.id AND f.status='approved')) AND NOT EXISTS(SELECT 1 FROM blocks b WHERE (b.user_id=? AND b.target_id=u.id) OR (b.user_id=u.id AND b.target_id=?)) ${saved?'AND EXISTS(SELECT 1 FROM bookmarks bm WHERE bm.user_id=? AND bm.post_id=p.id)':''} ORDER BY p.created_at DESC LIMIT 60`).all(...[viewer,category,category,'%'+q+'%',viewer,viewer,viewer,viewer,...(saved?[viewer]:[])]);
     return json(res,rows.map(p=>({...p,likes:db.prepare('SELECT COUNT(*) n FROM likes WHERE post_id=?').get(p.id).n,liked:!!db.prepare('SELECT 1 FROM likes WHERE user_id=? AND post_id=?').get(viewer,p.id),saved:!!db.prepare('SELECT 1 FROM bookmarks WHERE user_id=? AND post_id=?').get(viewer,p.id),comments:db.prepare("SELECT COUNT(*) n FROM comments WHERE post_id=? AND status='approved'").get(p.id).n})));
    }
    if(path==='/api/tournaments'&&method==='GET')return json(res,db.prepare('SELECT * FROM tournaments WHERE active=1 AND ends_at>? ORDER BY starts_at').all(now()).map(t=>({...t,participants:db.prepare('SELECT COUNT(DISTINCT p1) n FROM matches WHERE tournament=?').get(t.id).n})));
    fail(!u,'ابتدا وارد شوید.',401);
    if(path==='/api/me'&&method==='PATCH'){
     const interests=Array.isArray(b.interests)?[...new Set(b.interests)].slice(0,3).map(validCategory):JSON.parse(u.interests);
     let avatar=u.avatar;if(b.avatar){avatar=/^\/assets\/avatars\/(?:[1-9]|10)\.svg$/.test(b.avatar)?b.avatar:media(b.avatar,u.id);}
     db.prepare('UPDATE users SET name=?,bio=?,avatar=?,private=?,interests=? WHERE id=?').run(b.name?text(b.name,2,40):u.name,b.bio!==undefined?text(b.bio,0,300):u.bio,avatar,b.private!==undefined?Number(!!b.private):u.private,JSON.stringify(interests),u.id);return json(res,{user:pub(db.prepare('SELECT * FROM users WHERE id=?').get(u.id),true)});
    }
    if(path==='/api/upload'&&method==='POST'){if(u.role!=='admin')limited('upload:'+u.id,20);return json(res,uploadFile(b,u),201);}
    if(path==='/api/users'&&method==='GET'){const q=(url.searchParams.get('q')||'').slice(0,60);return json(res,db.prepare('SELECT id,name,avatar,bio,is_demo,xp FROM users WHERE banned=0 AND id<>? AND name LIKE ? ORDER BY is_demo ASC,created_at DESC LIMIT 100').all(u.id,'%'+q+'%').filter(x=>!game.blocked(u.id,x.id)).map(x=>({...x,isDemo:!!x.is_demo,level:Math.floor(x.xp/250)+1,online:now()-(presence.get(x.id)||0)<45000})));}
    const profile=path.match(/^\/api\/users\/([^/]+)$/);
    if(profile&&method==='GET'){
     const person=db.prepare('SELECT * FROM users WHERE id=? AND banned=0').get(profile[1]);fail(!person||game.blocked(u.id,person.id),'کاربر پیدا نشد.',404);const access=canSeeUser(u,person),f=db.prepare('SELECT status FROM follows WHERE user_id=? AND target_id=?').get(u.id,person.id);return json(res,{user:access?pub(person):{id:person.id,name:person.name,avatar:person.avatar,bio:person.bio,private:true},locked:!access,following:f?.status||false,followers:db.prepare("SELECT COUNT(*) n FROM follows WHERE target_id=? AND status='approved'").get(person.id).n,followingCount:db.prepare("SELECT COUNT(*) n FROM follows WHERE user_id=? AND status='approved'").get(person.id).n,stats:access?db.prepare('SELECT * FROM category_stats WHERE user_id=?').all(person.id):[]});
    }
    const follow=path.match(/^\/api\/users\/([^/]+)\/follow$/);
    if(follow&&method==='POST'){
     const target=db.prepare('SELECT * FROM users WHERE id=? AND banned=0').get(follow[1]);fail(!target||target.id===u.id||game.blocked(u.id,target.id),'کاربر نامعتبر است.');const existing=db.prepare('SELECT 1 FROM follows WHERE user_id=? AND target_id=?').get(u.id,target.id);
     if(existing)db.prepare('DELETE FROM follows WHERE user_id=? AND target_id=?').run(u.id,target.id);else {db.prepare('INSERT INTO follows VALUES (?,?,?)').run(u.id,target.id,target.private?'pending':'approved');notice(target.id,target.private?'درخواست دنبال‌کردن':'دنبال‌کنندهٔ تازه',u.name+(target.private?' درخواست دنبال‌کردن شما را دارد.':' شما را دنبال کرد.'));}return json(res,{ok:true});
    }
    if(path==='/api/follow-requests'&&method==='GET')return json(res,db.prepare("SELECT u.id,u.name,u.avatar FROM follows f JOIN users u ON u.id=f.user_id WHERE f.target_id=? AND f.status='pending'").all(u.id));
    if(path==='/api/follow-requests'&&method==='POST'){if(b.approve)db.prepare("UPDATE follows SET status='approved' WHERE user_id=? AND target_id=?").run(b.id,u.id);else db.prepare('DELETE FROM follows WHERE user_id=? AND target_id=?').run(b.id,u.id);return json(res,{ok:true});}
    if(path==='/api/block'&&method==='POST'){fail(!db.prepare('SELECT 1 FROM users WHERE id=?').get(b.id)||b.id===u.id,'کاربر نامعتبر است.');if(b.unblock)db.prepare('DELETE FROM blocks WHERE user_id=? AND target_id=?').run(u.id,b.id);else {db.prepare('INSERT OR IGNORE INTO blocks VALUES (?,?)').run(u.id,b.id);db.prepare('DELETE FROM follows WHERE (user_id=? AND target_id=?) OR (user_id=? AND target_id=?)').run(u.id,b.id,b.id,u.id);}return json(res,{ok:true});}
    if(path==='/api/blocks'&&method==='GET')return json(res,db.prepare('SELECT u.id,u.name,u.avatar FROM blocks b JOIN users u ON u.id=b.target_id WHERE b.user_id=?').all(u.id));
    if(path==='/api/feed'&&method==='POST'){
     fail(!setting('feedEnabled'),'فضای تجربه غیرفعال است.',403);limited('post:'+u.id,12,3600000);const id=uid(),status=setting('moderatePosts')&&u.role!=='admin'?'pending':'approved';db.prepare('INSERT INTO posts VALUES (?,?,?,?,?,?,?,?)').run(id,u.id,validCategory(b.category),text(b.body,3,4000),media(b.media,u.id),media(b.audio,u.id,['audio/']),status,now());return json(res,{id,status},201);
    }
    const action=path.match(/^\/api\/posts\/([^/]+)\/(like|save|comments)$/);
    if(action){const p=postAccess(action[1],u),kind=action[2];
     if(kind==='comments'&&method==='GET')return json(res,db.prepare("SELECT c.*,u.name,u.avatar,(SELECT COUNT(*) FROM comment_likes cl WHERE cl.comment_id=c.id) likes,(SELECT cr.parent_id FROM comment_replies cr WHERE cr.comment_id=c.id) parent FROM comments c JOIN users u ON c.user_id=u.id WHERE c.post_id=? AND (c.status='approved' OR c.user_id=?) AND u.banned=0 ORDER BY c.created_at").all(p.id,u.id));
     if(method==='POST'){
      if(kind==='comments'){const status=setting('moderateComments')&&u.role!=='admin'?'pending':'approved';db.prepare('INSERT INTO comments VALUES (?,?,?,?,?,?)').run(uid(),u.id,p.id,text(b.body,1,1000),status,now());return json(res,{status},201);}
      const table=kind==='like'?'likes':'bookmarks',exists=db.prepare(`SELECT 1 FROM ${table} WHERE user_id=? AND post_id=?`).get(u.id,p.id);if(exists)db.prepare(`DELETE FROM ${table} WHERE user_id=? AND post_id=?`).run(u.id,p.id);else db.prepare(`INSERT INTO ${table} VALUES (?,?)`).run(u.id,p.id);return json(res,{active:!exists});
     }
    }
    const ownPost=path.match(/^\/api\/posts\/([^/]+)$/);if(ownPost&&method==='DELETE'){const p=postAccess(ownPost[1],u);fail(p.user_id!==u.id&&u.role!=='admin','اجازهٔ حذف ندارید.',403);db.prepare('DELETE FROM posts WHERE id=?').run(p.id);return json(res,{ok:true});}
    if(path==='/api/conversations'&&method==='GET'){
     fail(!setting('chatEnabled'),'گفت‌وگو غیرفعال است.',403);const rows=db.prepare('SELECT * FROM messages WHERE sender=? OR recipient=? ORDER BY created_at DESC LIMIT 500').all(u.id,u.id),map=new Map();for(const m of rows){const other=m.sender===u.id?m.recipient:m.sender;if(!map.has(other)&&!game.blocked(u.id,other))map.set(other,{...db.prepare('SELECT id,name,avatar,is_demo FROM users WHERE id=? AND banned=0').get(other),last:m.body||(m.media?'تصویر':''),created_at:m.created_at,unread:db.prepare('SELECT COUNT(*) n FROM messages WHERE sender=? AND recipient=? AND seen=0').get(other,u.id).n});}return json(res,[...map.values()].filter(x=>x.id));
    }
    const messages=path.match(/^\/api\/messages\/([^/]+)$/);
    if(messages&&messages[1]!=='read'){fail(!setting('chatEnabled'),'گفت‌وگو غیرفعال است.',403);const target=db.prepare("SELECT * FROM users WHERE id=? AND banned=0 AND role<>'guide'").get(messages[1]);fail(!target||target.id===u.id||game.blocked(u.id,target.id),'گفت‌وگو با این کاربر در دسترس نیست.',403);
     if(method==='GET')return json(res,db.prepare('SELECT m.*,EXISTS(SELECT 1 FROM message_tombstones d WHERE d.id=m.id) deleted FROM messages m WHERE (sender=? AND recipient=?) OR (sender=? AND recipient=?) ORDER BY created_at DESC LIMIT 100').all(u.id,target.id,target.id,u.id).reverse());
     if(method==='POST'){fail(!canSeeUser(u,target),'برای پیام دادن به این حساب خصوصی، درخواست دنبال‌کردن شما باید پذیرفته شود.',403);limited('message:'+u.id,40);const message=text(b.body||'',0,2000),file=media(b.media,u.id);fail(!message&&!file,'پیام یا تصویر لازم است.');const m={id:uid(),sender:u.id,recipient:target.id,body:message,media:file,created_at:now()};db.prepare('INSERT INTO messages VALUES (?,?,?,?,?,?,0)').run(m.id,m.sender,m.recipient,m.body,m.media,m.created_at);notify(target.id,'message',m);return json(res,m,201);}
    }
    if(path==='/api/messages/read'&&method==='PATCH'){db.prepare('UPDATE messages SET seen=1 WHERE sender=? AND recipient=?').run(b.id,u.id);return json(res,{ok:true});}
    if(path==='/api/notifications'&&method==='GET')return json(res,db.prepare("SELECT n.*,COALESCE(l.link,'') link FROM notifications n LEFT JOIN notification_links l ON l.id=n.id WHERE n.user_id=? ORDER BY n.created_at DESC LIMIT 50").all(u.id));
    if(path==='/api/notifications/read'&&method==='POST'){db.prepare('UPDATE notifications SET seen=1 WHERE user_id=?').run(u.id);return json(res,{ok:true});}
    if(path==='/api/report'&&method==='POST'){limited('report:'+u.id,10,3600000);const kind=['post','user','question','bug'].includes(b.kind)?b.kind:'bug';db.prepare('INSERT INTO reports VALUES (?,?,?,?,?,?,?)').run(uid(),u.id,kind,String(b.target||'').slice(0,100),text(b.body,5,2000),'open',now());return json(res,{ok:true},201);}
    if(path==='/api/questions/suggest'&&method==='POST'){limited('suggest:'+u.id,20,3600000);const q=validateQuestion(b,u);db.prepare('INSERT INTO questions(id,category,title,options,correct,explanation,source,seconds,kind,media,audio,status,author) VALUES (?,?,?,?,?,?,?,?,?,?,?,\'pending\',?)').run(q.id,q.category,q.title,q.options,q.correct,q.explanation,q.source,q.seconds,q.kind,q.media,q.audio,u.id);return json(res,{id:q.id,status:'pending'},201);}
    if(path==='/api/reviews'&&method==='GET')return json(res,db.prepare("SELECT q.id,q.category,q.title,q.explanation,q.options,q.correct,q.source,r.due_at FROM reviews r JOIN questions q ON r.question_id=q.id WHERE r.user_id=? AND q.status='approved' ORDER BY r.due_at LIMIT 100").all(u.id).map(x=>({...x,options:JSON.parse(x.options)})));
    if(path==='/api/history'&&method==='GET')return json(res,db.prepare("SELECT id,category,mode,score1,score2,p1,p2,finished_at FROM matches WHERE (p1=? OR p2=?) AND state='finished' ORDER BY finished_at DESC LIMIT 30").all(u.id,u.id));
    if(path==='/api/matches'&&method==='POST'){fail(!['practice','review','private','tournament'].includes(b.mode),'نوع مسابقه نامعتبر است.');return json(res,game.create(u.id,b.category,b.mode,null,b.tournament||null),201);}
    if(path==='/api/matchmaking'&&method==='POST')return json(res,game.enqueue(u.id,b.category));
    if(path==='/api/matchmaking'&&method==='DELETE'){game.queue.delete(u.id);return json(res,{ok:true});}
    if(path==='/api/matchmaking'&&method==='GET'){const active=game.active(u.id);if(active)return json(res,{match:game.view(active.id,u.id)});const q=game.queue.get(u.id);if(q)q.at=now();return json(res,{queued:!!q,category:q?.category});}
    if(path==='/api/matches/join'&&method==='POST')return json(res,game.join(u.id,text(b.code,4,12)));
    const match=path.match(/^\/api\/matches\/([^/]+)(?:\/(answer|lifeline|leave|next))?$/);
    if(match){const id=match[1],a=match[2];if(!a&&method==='GET')return json(res,game.view(id,u.id));if(method==='POST'){
     if(a==='answer')return json(res,game.answer(id,u.id,b.round,b.choice));
     if(a==='lifeline')return json(res,game.lifeline(id,u.id,b.kind));
     if(a==='leave'){game.cancel(id,u.id);return json(res,{ok:true});}
     if(a==='next'){const m=game.get(id);fail(!m||m.p1!==u.id||m.p2||m.state!=='reveal','این عمل مجاز نیست.');db.prepare('UPDATE matches SET round_at=? WHERE id=?').run(now()-5000,id);game.advance(game.get(id));return json(res,game.view(id,u.id));}
    }}
    if(path==='/api/shop'&&method==='GET')return json(res,{items:[{id:'frame-gold',name:'قاب طلایی قهرمان',price:120,icon:'crown'},{id:'frame-violet',name:'قاب بنفش کهکشانی',price:80,icon:'spark'},{id:'title-mentor',name:'نشان استاد تجربه',price:200,icon:'medal'}],owned:db.prepare('SELECT item FROM inventory WHERE user_id=?').all(u.id).map(x=>x.item)});
    if(path==='/api/shop/buy'&&method==='POST'){fail(!setting('shopEnabled'),'فروشگاه غیرفعال است.',403);const price={'frame-gold':120,'frame-violet':80,'title-mentor':200}[b.item];fail(!price,'کالا پیدا نشد.');transaction(()=>{fail(db.prepare('SELECT 1 FROM inventory WHERE user_id=? AND item=?').get(u.id,b.item),'این آیتم را دارید.');fail(!db.prepare('UPDATE users SET coins=coins-? WHERE id=? AND coins>=?').run(price,u.id,price).changes,'سکهٔ کافی ندارید.');db.prepare('INSERT INTO inventory VALUES (?,?)').run(u.id,b.item);});return json(res,{ok:true});}
    if(path==='/api/admin/unlock'&&method==='POST'){limited('admin:'+ip,5,900000);const supplied=hash(typeof b.key==='string'?b.key:''),expected=hash(adminKey);fail(!timingSafeEqual(Buffer.from(supplied),Buffer.from(expected)),'کد مدیریت صحیح نیست.',403);db.prepare("UPDATE users SET role='admin' WHERE id=?").run(u.id);audit(u.id,'admin-unlock');return json(res,{ok:true});}
    if(path.startsWith('/api/admin/')){
      fail(u.role!=='admin','این بخش فقط برای مدیر است.',403);
      const deleteQuestion=path.match(/^\/api\/admin\/questions\/([^/]+)$/);
      if(deleteQuestion&&method==='DELETE'){transaction(()=>{db.prepare('DELETE FROM reviews WHERE question_id=?').run(deleteQuestion[1]);db.prepare('DELETE FROM question_metadata WHERE question_id=?').run(deleteQuestion[1]);fail(!db.prepare('DELETE FROM questions WHERE id=?').run(deleteQuestion[1]).changes,'سؤال پیدا نشد.',404);audit(u.id,'delete-question',deleteQuestion[1]);});return json(res,{ok:true});}
      if(path==='/api/admin/demo-users'&&method==='GET')return json(res,db.prepare("SELECT id,name,avatar,xp,cups FROM users WHERE is_demo=1 AND id LIKE 'demo-v2-%' ORDER BY created_at DESC").all());
      if(path==='/api/admin/demo-users'&&method==='DELETE'){
       const ids=db.prepare("SELECT id FROM users WHERE is_demo=1 AND id LIKE 'demo-v2-%' AND (?='' OR id=?)").all(b.id||'',b.id||'').map(x=>x.id);
       transaction(()=>{for(const id of ids){
        db.prepare('DELETE FROM posts WHERE user_id=?').run(id);
        for(const table of ['likes','bookmarks','comments','category_stats','notifications','sessions','reviews','inventory','reports'])db.prepare(`DELETE FROM ${table} WHERE user_id=?`).run(id);
        db.prepare('DELETE FROM follows WHERE user_id=? OR target_id=?').run(id,id);db.prepare('DELETE FROM blocks WHERE user_id=? OR target_id=?').run(id,id);
        db.prepare('DELETE FROM messages WHERE sender=? OR recipient=?').run(id,id);
        db.prepare('DELETE FROM scheduled_posts WHERE author=?').run(id);db.prepare('DELETE FROM player_details WHERE user_id=?').run(id);
        db.prepare('DELETE FROM cosmetics WHERE user_id=?').run(id);
        db.prepare('DELETE FROM users WHERE id=?').run(id);
       }audit(u.id,'delete-demo-users',String(ids.length));});return json(res,{count:ids.length});
      }
      if(path==='/api/admin/excel/preview'&&method==='POST'){
       limited('excel:'+u.id,8);fail(typeof b.data!=='string'||b.data.length>7*1024*1024||!/^[A-Za-z0-9+/]*={0,2}$/.test(b.data),'فایل اکسل نامعتبر است.');
       let mapped;try{mapped=mapRows(await parseWorkbook(Buffer.from(b.data,'base64')),db.prepare('SELECT id,name FROM categories WHERE active=1').all());}catch(e){throw new GameError(e.message);}
       const seen=new Set(db.prepare('SELECT category,title FROM questions').all().map(questionKey));
       const rows=mapped.map(r=>{if(r.error)return r;try{const q=validateQuestion(r.question,u),key=questionKey(q);if(seen.has(key))return {row:r.row,error:'سؤال تکراری در همین فایل یا بانک سؤال است.'};seen.add(key);return {row:r.row,question:{...q,options:JSON.parse(q.options)}};}catch(e){return {row:r.row,error:e.message};}});
       for(const [key,v] of excelPreviews)if(v.expires<now()||v.owner===u.id)excelPreviews.delete(key);
       fail(excelPreviews.size>=30,'سامانه مشغول است؛ کمی بعد امتحان کنید.',429);
       const token=uid();excelPreviews.set(token,{owner:u.id,expires:now()+15*60000,rows});
       return json(res,{token,rows,valid:rows.filter(x=>!x.error).length,errors:rows.filter(x=>x.error).length});
      }
      if(path==='/api/admin/excel/commit'&&method==='POST'){
       const preview=excelPreviews.get(b.token);fail(!preview||preview.owner!==u.id||preview.expires<now(),'پیش‌نمایش منقضی شده؛ فایل را دوباره بررسی کنید.');
       fail(preview.rows.some(r=>r.error),'ابتدا خطاهای فایل را اصلاح کنید. هیچ سؤالی ثبت نشده است.');
       fail(!['pending','approved'].includes(b.status),'وضعیت انتشار نامعتبر است.');
       const questions=preview.rows.map(r=>validateQuestion(r.question,u));
       transaction(()=>{const seen=new Set(db.prepare('SELECT category,title FROM questions').all().map(questionKey));for(const q of questions){fail(seen.has(questionKey(q)),'یکی از سؤال‌ها قبلاً ثبت شده است؛ فایل را دوباره بررسی کنید.');seen.add(questionKey(q));db.prepare('INSERT INTO questions(id,category,title,options,correct,explanation,source,seconds,kind,media,audio,status,author) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').run(q.id,q.category,q.title,q.options,q.correct,q.explanation,q.source,q.seconds,q.kind,q.media,q.audio,b.status,u.id);}audit(u.id,'excel-import',String(questions.length));});
       excelPreviews.delete(b.token);return json(res,{count:questions.length,status:b.status});
      }
     if(path==='/api/admin/dashboard'&&method==='GET')return json(res,{users:db.prepare('SELECT COUNT(*) n FROM users WHERE is_demo=0').get().n,matches:db.prepare("SELECT COUNT(*) n FROM matches WHERE state='finished'").get().n,questions:db.prepare('SELECT COUNT(*) n FROM questions').get().n,pending:db.prepare("SELECT (SELECT COUNT(*) FROM posts WHERE status='pending')+(SELECT COUNT(*) FROM questions WHERE status='pending')+(SELECT COUNT(*) FROM comments WHERE status='pending') n").get().n,settings:settings(),reports:db.prepare('SELECT r.*,u.name FROM reports r JOIN users u ON u.id=r.user_id ORDER BY created_at DESC LIMIT 100').all(),log:db.prepare('SELECT a.*,u.name FROM audit_log a LEFT JOIN users u ON a.actor=u.id ORDER BY created_at DESC LIMIT 30').all()});
     if(path==='/api/admin/questions'&&method==='GET')return json(res,db.prepare("SELECT q.*,COALESCE(md.subcategory,'') subcategory,COALESCE(md.language,'fa') language,COALESCE(md.difficulty,'medium') difficulty,md.created_at,md.last_verified FROM questions q LEFT JOIN question_metadata md ON md.question_id=q.id ORDER BY q.rowid DESC LIMIT 5000").all().map(q=>({...q,options:JSON.parse(q.options)})));
     if(path==='/api/admin/questions'&&method==='POST'){
      const old=b.id?db.prepare('SELECT * FROM questions WHERE id=?').get(b.id):null;
      // Existing media remains valid on edits; newly supplied media must belong to the editing admin.
      const q=validateQuestion({...b,media:old&&b.media===old.media?'':b.media,audio:old&&b.audio===old.audio?'':b.audio,kind:old&&b.media===old.media?'text':b.kind},u);
      if(old&&b.media===old.media){q.media=old.media;q.kind=b.kind||old.kind;}if(old&&b.audio===old.audio)q.audio=old.audio;
      const subcategory=text(b.subcategory||'',0,100),language=b.language||'fa',difficulty=b.difficulty||'medium';fail(!['fa','en','ar','de'].includes(language)||!['easy','medium','hard'].includes(difficulty),'زبان یا دشواری معتبر نیست.');
      const status=['approved','pending','rejected'].includes(b.status)?b.status:'approved';
      db.prepare('INSERT INTO questions(id,category,title,options,correct,explanation,source,seconds,kind,media,audio,status,author) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET category=excluded.category,title=excluded.title,options=excluded.options,correct=excluded.correct,explanation=excluded.explanation,source=excluded.source,seconds=excluded.seconds,kind=excluded.kind,media=excluded.media,audio=excluded.audio,status=excluded.status').run(q.id,q.category,q.title,q.options,q.correct,q.explanation,q.source,q.seconds,q.kind,q.media,q.audio,status,old?.author||u.id);
      db.prepare('INSERT INTO question_metadata VALUES (?,?,?,?,?,?) ON CONFLICT(question_id) DO UPDATE SET subcategory=excluded.subcategory,language=excluded.language,difficulty=excluded.difficulty,last_verified=excluded.last_verified').run(q.id,subcategory,language,difficulty,now(),status==='approved'?now():null);
      if(old?.author&&status==='approved'&&!old.rewarded&&old.author!==u.id){db.prepare('UPDATE users SET coins=coins+30 WHERE id=?').run(old.author);db.prepare('UPDATE questions SET rewarded=1 WHERE id=?').run(q.id);notice(old.author,'سؤالت تأیید شد!','۳۰ سکه پاداش مشارکت به حسابت اضافه شد.');}
      audit(u.id,'save-question',q.id);return json(res,{id:q.id});
     }
     if(path==='/api/admin/import'&&method==='POST'){fail(!Array.isArray(b.questions)||b.questions.length>500||!b.questions.length,'۱ تا ۵۰۰ سؤال وارد کنید.');const questions=b.questions.map(x=>validateQuestion({...x,id:uid()},u));transaction(()=>{for(const q of questions)db.prepare("INSERT INTO questions(id,category,title,options,correct,explanation,source,seconds,kind,media,audio,status,author) VALUES (?,?,?,?,?,?,?,?,?,?,?,'pending',?)").run(q.id,q.category,q.title,q.options,q.correct,q.explanation,q.source,q.seconds,q.kind,q.media,q.audio,u.id);});audit(u.id,'import-questions',String(questions.length));return json(res,{count:questions.length});}
     if(path==='/api/admin/categories'&&method==='GET')return json(res,db.prepare('SELECT * FROM categories').all());
     if(path==='/api/admin/categories'&&method==='POST'){const id=b.id||uid();const icon=['shield','bolt','globe','flask','cpu','briefcase','leaf','ball','book'].includes(b.icon)?b.icon:'book';fail(!/^#[0-9a-fA-F]{6}$/.test(b.color||''),'رنگ معتبر انتخاب کنید.');db.prepare('INSERT INTO categories(id,name,subtitle,icon,color,tag,safety,active) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,subtitle=excluded.subtitle,icon=excluded.icon,color=excluded.color,tag=excluded.tag,safety=excluded.safety,active=excluded.active').run(id,text(b.name,2,60),text(b.subtitle||'',0,120),icon,b.color,text(b.tag||'',0,30),Number(!!b.safety),b.active===false?0:1);audit(u.id,'save-category',id);return json(res,{id});}
     if(path==='/api/admin/users'&&method==='GET')return json(res,db.prepare('SELECT id,name,avatar,role,banned,xp,coins,cups,created_at FROM users WHERE is_demo=0 ORDER BY created_at DESC LIMIT 1000').all());
     if(path==='/api/admin/users'&&method==='PATCH'){fail(b.id===u.id,'حساب مدیر فعلی قابل غیرفعال‌کردن نیست.');const target=db.prepare('SELECT * FROM users WHERE id=?').get(b.id);fail(!target,'کاربر پیدا نشد.');fail(target.role==='admin','تغییر وضعیت مدیر دیگر از این بخش مجاز نیست.');db.prepare('UPDATE users SET banned=? WHERE id=?').run(Number(!!b.banned),b.id);if(b.banned){db.prepare('DELETE FROM sessions WHERE user_id=?').run(b.id);game.queue.delete(b.id);for(const r of streams.get(b.id)||[])r.end();streams.delete(b.id);}audit(u.id,'user-status',b.id);return json(res,{ok:true});}
     if(path==='/api/admin/moderation'&&method==='GET')return json(res,{posts:db.prepare('SELECT p.*,u.name FROM posts p JOIN users u ON p.user_id=u.id ORDER BY created_at DESC LIMIT 200').all(),comments:db.prepare('SELECT c.*,u.name FROM comments c JOIN users u ON c.user_id=u.id ORDER BY created_at DESC LIMIT 200').all()});
     if(path==='/api/admin/moderation'&&method==='PATCH'){const table={post:'posts',comment:'comments',question:'questions',report:'reports'}[b.kind];fail(!table,'نوع محتوا نامعتبر است.');const states=table==='reports'?['open','resolved']:['approved','rejected','pending'];fail(!states.includes(b.status),'وضعیت نامعتبر است.');const row=db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(b.id);fail(!row,'مورد پیدا نشد.');transaction(()=>{db.prepare(`UPDATE ${table} SET status=? WHERE id=?`).run(b.status,b.id);if(table==='questions'&&b.status==='approved'&&row.author&&!row.rewarded){db.prepare('UPDATE users SET coins=coins+30 WHERE id=?').run(row.author);db.prepare('UPDATE questions SET rewarded=1 WHERE id=?').run(b.id);notice(row.author,'سؤال شما تأیید شد','۳۰ سکه پاداش گرفتی.');}});audit(u.id,'moderate-'+b.kind,b.id);return json(res,{ok:true});}
     if(path==='/api/admin/settings'&&method==='PATCH'){const booleans=['chatEnabled','feedEnabled','shopEnabled','moderatePosts','moderateComments','safetyReviewed'];for(const key of booleans)if(key in b){fail(typeof b[key]!=='boolean','تنظیم نامعتبر است.');db.prepare('UPDATE settings SET value=? WHERE key=?').run(JSON.stringify(b[key]),key);}for(const key of ['siteTitle','welcome'])if(key in b)db.prepare('UPDATE settings SET value=? WHERE key=?').run(JSON.stringify(text(b[key],1,140)),key);
      if('banners'in b){fail(!Array.isArray(b.banners)||b.banners.length>6,'حداکثر شش بنر مجاز است.');const banners=b.banners.map(x=>({image:media(x.image,u.id),title:text(x.title,1,80),category:validCategory(x.category)}));db.prepare("UPDATE settings SET value=? WHERE key='banners'").run(JSON.stringify(banners));}audit(u.id,'save-settings');return json(res,{ok:true});}
     if(path==='/api/admin/notify'&&method==='POST'){const title=text(b.title,2,120),message=text(b.body,2,600),link=b.link||'';fail(link&&!safeLink(link),'لینک داخلی یا HTTPS وارد کنید.');const recipients=b.user?db.prepare('SELECT id FROM users WHERE id=? AND banned=0 AND is_demo=0').all(b.user):db.prepare('SELECT id FROM users WHERE banned=0 AND is_demo=0').all();fail(!recipients.length,'کاربری برای دریافت پیدا نشد.');for(const user of recipients)notice(user.id,title,message,link);audit(u.id,'send-notification',String(recipients.length));return json(res,{count:recipients.length});}
     if(path==='/api/admin/tournaments'&&method==='GET')return json(res,db.prepare('SELECT * FROM tournaments ORDER BY starts_at DESC').all());
     if(path==='/api/admin/tournaments'&&method==='POST'){if(b.id)fail(db.prepare('SELECT 1 FROM matches WHERE tournament=?').get(b.id),'پس از شروع مشارکت، مشخصات رویداد قابل تغییر نیست. یک رویداد جدید بسازید.');const start=Number(b.starts_at),end=Number(b.ends_at);fail(!Number.isFinite(start)||!Number.isFinite(end)||end<=start||end<now(),'زمان رویداد معتبر نیست.');const id=b.id||uid();db.prepare('INSERT INTO tournaments VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,category=excluded.category,starts_at=excluded.starts_at,ends_at=excluded.ends_at,description=excluded.description,active=excluded.active').run(id,text(b.title,3,80),validCategory(b.category),start,end,text(b.description||'',0,500),b.active===false?0:1);audit(u.id,'save-tournament',id);return json(res,{id});}
     if(path==='/api/admin/export'&&method==='GET')return json(res,{version:1,exportedAt:new Date().toISOString(),categories:db.prepare('SELECT * FROM categories').all(),questions:db.prepare('SELECT * FROM questions').all().map(q=>({...q,options:JSON.parse(q.options)})),settings:settings()});
    }
    throw new GameError('این درخواست پیدا نشد.',404);
   }
   if(method!=='GET'&&method!=='HEAD')throw new GameError('روش درخواست مجاز نیست.',405);
   let file,mime;
   if(path.startsWith('/uploads/')){
    const f=db.prepare('SELECT * FROM uploads WHERE path=?').get(path);fail(!f,'فایل پیدا نشد.',404);
    const publishedPosts=db.prepare("SELECT p.*,u.private FROM posts p JOIN users u ON p.user_id=u.id WHERE p.status='approved' AND (p.media=? OR p.audio=?)").all(path,path);
    const publicPost=publishedPosts.some(p=>canSeeUser(u,{id:p.user_id,private:p.private}));
    const avatar=db.prepare('SELECT 1 FROM users WHERE avatar=? AND banned=0').get(path),question=db.prepare("SELECT 1 FROM questions WHERE (media=? OR audio=?) AND status='approved'").get(path,path),msg=u?db.prepare('SELECT 1 FROM messages WHERE media=? AND (sender=? OR recipient=?)').get(path,u.id,u.id):false;
    const storyMedia=db.prepare("SELECT s.user_id,u.private FROM stories s JOIN users u ON u.id=s.user_id WHERE s.media=? AND s.status='approved' AND s.expires_at>? AND u.banned=0").all(path,now()).some(p=>canSeeUser(u,{id:p.user_id,private:p.private})&&!game.blocked(u?.id||'',p.user_id));const library=db.prepare('SELECT 1 FROM resource_library WHERE path=?').get(path);const branding=['siteLogo','audioFiles','slides'].some(k=>{const value=setting(k);return k==='siteLogo'?value===path:k==='audioFiles'?Object.values(value||{}).includes(path):(value||[]).some(x=>x.image===path);})||db.prepare('SELECT 1 FROM org_spaces WHERE active=1 AND (logo=? OR banner=?)').get(path,path);if(library&&['application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(f.mime))res.setHeader('Content-Disposition','attachment');fail(!(u?.id===f.owner||u?.role==='admin'||publicPost||avatar||question||msg||library||branding||storyMedia),'اجازهٔ مشاهدهٔ فایل را ندارید.',403);file=resolve(data,'uploads',path.split('/').pop());mime=f.mime;res.setHeader('Cache-Control','private, no-store');
   }else{
    let clean;try{clean=decodeURIComponent(path);}catch{throw new GameError('نشانی نامعتبر است.',400);}
    file=resolve(PUBLIC,'.'+clean);fail(file!==PUBLIC&&!file.startsWith(PUBLIC+sep),'نشانی مجاز نیست.',403);
    if(clean==='/'||!extname(clean))file=resolve(PUBLIC,'index.html');
    fail(!existsSync(file)||!statSync(file).isFile(),'فایل پیدا نشد.',404);
    res.setHeader('Cache-Control',path.startsWith('/assets/')?'public, max-age=86400':'no-cache');
   }
   mime||=({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json','.webmanifest':'application/manifest+json','.ttf':'font/ttf','.mp3':'audio/mpeg','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.wav':'audio/wav','.ogg':'audio/ogg','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.mp4':'video/mp4'}[extname(file)]||'application/octet-stream');
   const size=statSync(file).size;res.setHeader('Content-Type',mime);res.setHeader('Accept-Ranges','bytes');
   const range=req.headers.range;if(range){const m=range.match(/^bytes=(\d+)-(\d*)$/);fail(!m,'بازه نامعتبر است.',416);const start=Number(m[1]),end=m[2]?Math.min(Number(m[2]),size-1):size-1;fail(start>=size||start>end,'بازه نامعتبر است.',416);res.writeHead(206,{'Content-Range':`bytes ${start}-${end}/${size}`,'Content-Length':end-start+1});return method==='HEAD'?res.end():createReadStream(file,{start,end}).pipe(res);}
   res.setHeader('Content-Length',size);if(method==='HEAD')return res.end();createReadStream(file).pipe(res);
  }catch(e){if(res.headersSent){res.end();return;}if(!(e instanceof GameError))console.error('[server]',e);json(res,{error:e instanceof GameError?e.message:'خطایی در سرور رخ داد. دوباره تلاش کنید.'},e.status||500);}
 });
 server.requestTimeout=30000;server.headersTimeout=15000;
 const ticker=setInterval(()=>{try{game.tick();}catch(e){console.error('[game]',e);}},300);ticker.unref();
 const cleaner=setInterval(()=>{try{settleCompetitions(db);platformTick(db);}catch(e){console.error('[competitions]',e);}for(const [k,v]of limits)if(now()-v.at>3600000)limits.delete(k);for(const [k,v]of oauthStates)if(now()-v.at>600000)oauthStates.delete(k);for(const [k,v]of presence)if(now()-v>60000)presence.delete(k);db.prepare('DELETE FROM sessions WHERE expires<?').run(now());},60000);cleaner.unref();
 return {server,db,game,close:()=>{clearInterval(ticker);clearInterval(cleaner);for(const set of streams.values())for(const res of set)res.end();return new Promise(r=>server.close(()=>{db.close();r();}));}};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const app=createApp(),port=Number(process.env.PORT)||3000,host=process.env.HOST||'127.0.0.1';app.server.listen(port,host,()=>console.log(`Gamify 2: ${process.env.BASE_URL||'http://localhost:'+port}\nOwner key: data/admin-key.txt\nGoogle login: ${process.env.GOOGLE_CLIENT_ID?'configured':'not configured (guest login available)'}`));
 for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>app.close().then(()=>process.exit(0)));
}
